package au.csiro.browser;


import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

import jdbm.PrimaryTreeMap;
import au.csiro.browser.query.MeasureDAO;
import au.csiro.browser.query.QueryStringParser;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;
import au.csiro.browser.rankingmodel.bm25.BM25Model;
import au.csiro.browser.rankingmodel.pageRank.PageRank;
import au.csiro.browser.rankingmodel.random.BooleanModel;
import au.csiro.browser.rankingmodel.structuralMetrices.BetweennessMeasure;
import au.csiro.browser.rankingmodel.structuralMetrices.ClassMatchMeasure;
import au.csiro.browser.rankingmodel.structuralMetrices.DensityMeasure;
import au.csiro.browser.rankingmodel.structuralMetrices.SemanticSimilarityMeasure;
import au.csiro.browser.rankingmodel.tf_Idf.TF_IDFModel;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.rankingmodel.vectorspace.VectorSpaceModel;

public class CopyOfTopResults {
	private static TfIdf_Data tfIdfClass= TfIdf_Data.getDefaultMap();
  	private static PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
	

  	public static void main(String[] args)  { 
  		
  		String query = "address";
  		String fileName = "/usr/local/data/files/"+query+"_new.csv";
  		Model model = ModelFactory.createDefaultModel();
  		MeasureDAO measureDao = new MeasureDAO();
  		
  		QueryStringParser stringParser = new  QueryStringParser();
  		ArrayList<String> queryWords = stringParser.parserQueryString(query);
  		model= measureDao.getSearchResults(queryWords); 
  		ArrayList<String> map = new ArrayList<String>(); 
  		
  		try
  		{
  		    FileWriter writer = new FileWriter(fileName);
  		   
  		    	ArrayList<ResultFormatter> rankedClassList = new ArrayList<ResultFormatter>();
  		    	//TopResults topresults = new TopResults();
  				
  		    	BooleanModel rankModel = new BooleanModel();
  				rankedClassList = rankModel.getRankedClasses(model);
  				map = getTopTen(rankedClassList, "boolean");
  				rankedClassList.clear();
  	  			
  				writer.append("boolean");
  				writer.append('\n');
  	  		    for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				
  				
  				TF_IDFModel rankModel2 = new TF_IDFModel();
  				rankedClassList = rankModel2.getRankedClasses(model);
  				map = getTopTen(rankedClassList, "tf_idf");
  				rankedClassList.clear();
  				writer.append("tf_idf");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();

  				BM25Model rankModel3 = new BM25Model();
  				rankedClassList = rankModel3.getRankedClasses(model);
  				map = getTopTen(rankedClassList, "bm25");
  				rankedClassList.clear();
  				writer.append("bm25");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				
  				
  				
  				VectorSpaceModel rankModel4 = new VectorSpaceModel();
  				rankedClassList = rankModel4.getRankedClasses(model,queryWords);	
  				map = getTopTen(rankedClassList, "VectorSpaceModel");
  				rankedClassList.clear();
  				writer.append("vector-space");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				
  				ClassMatchMeasure rankModel5 = new ClassMatchMeasure();
  				rankedClassList = rankModel5.getRankedClasses(model,queryWords);
  				map = getTopTen(rankedClassList, "ClassMatchMeasure");
  				rankedClassList.clear();
  				writer.append("class-match-measure");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				
  				DensityMeasure rankModel6 = new DensityMeasure();
  				rankedClassList = rankModel6.getRankedClasses(model,queryWords);
  				map = getTopTen(rankedClassList, "DensityMeasure");
  				rankedClassList.clear();
  				writer.append("density-measure");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				
  				SemanticSimilarityMeasure rankModel7 = new SemanticSimilarityMeasure();
  				rankedClassList = rankModel7.getRankedClasses(model,queryWords);
  				map = getTopTen(rankedClassList, "SemanticSimilarityMeasure");
  				rankedClassList.clear();
  				writer.append("semantic-similarity");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				
  				PageRank rankModel8 = new PageRank();
  				rankedClassList = rankModel8.getRankedClasses(model,queryWords);
  				map = getTopTen(rankedClassList, "PageRank");
  				rankedClassList.clear();
  				writer.append("pagerank");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				
  				BetweennessMeasure rankModel9 = new BetweennessMeasure();
  				rankedClassList = rankModel9.getRankedClasses(model,queryWords);
  				map = getTopTen(rankedClassList, "BetweennessMeasure");
  				rankedClassList.clear();
  				writer.append("between-measure");
  				writer.append('\n');
  				for (int count=0; count<map.size(); count++) {
  	  		        writer.append(map.get(count));
  	  		        writer.append('\n');
  	  		        writer.flush();
  	  		    }
  	  		    writer.append('\n');
  				map.clear();
  				    
  		    writer.close();
  		}
  		catch(IOException e)
  		{
  		     e.printStackTrace();
  		} 

  	}
  	
  	
	public static ArrayList<String> getTopTen (ArrayList<ResultFormatter> list, String rankingModel){
		HashMap<String, Double> sorted = new HashMap<String, Double>();
		
		ArrayList<String> strings = new ArrayList<String>();
		int numberOfURIs = 10;
		if (list.size()<10) {
			numberOfURIs = list.size();
		}
		HashMap<String, Double> URImap = new HashMap<String, Double>();
		
		//if(rankingModel.equalsIgnoreCase("boolean") || rankingModel.equalsIgnoreCase("tf_idf") || rankingModel.equalsIgnoreCase("pagerank")){
			for(int j=0; j<numberOfURIs; j++){  
				ResultFormatter searchFacet = (ResultFormatter)list.get(j);
				String term = searchFacet.getTermIRI();
				strings.add(term);
//			}
//		} else {
//			
//			for(int j=0; j<numberOfURIs; j++){  
//
//				ResultFormatter searchFacet = (ResultFormatter)list.get(j);
//				String term = searchFacet.getTermIRI();
//				String graph= searchFacet.getGraphIRI();
//			
//				TF_IDFHolder holder = new TF_IDFHolder();
//				holder = getTF_IDFValues(term, graph);
//				double tfIdf = holder.getTF_IDF();
//				sorted.put(term, tfIdf);
//
//				}
//				
//			}
//		
			
		}
		
	//	System.out.println("SortedMap" + sorted);
		return strings;
	}

	private static TF_IDFHolder getTF_IDFValues(String term, String graphIRI){
 		//System.out.println("TERMS " + term +" GRAPHS " + graphIRI );
 		TF_IDFHolder tf_IdfHolder = new TF_IDFHolder();
 		
 		  double tf = 0;
		  double idf = 0;
		  double tf_idf = 0;
		  
		  if (corpus_tfIdf_Map.containsKey(graphIRI)) {
    			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(graphIRI);
    			if(ontologyTfIDFs.containsKey(term)) {
    				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(term);
    		  		tf = tfIdfs.get(1);
    				idf = tfIdfs.get(2);
    				tf_idf = tfIdfs.get(3);
    			}
    		}
	  
		  	tf_IdfHolder = new TF_IDFHolder(tf, idf, tf_idf);    
		  	return tf_IdfHolder;
 	}
	  private static  HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
	  

	
}