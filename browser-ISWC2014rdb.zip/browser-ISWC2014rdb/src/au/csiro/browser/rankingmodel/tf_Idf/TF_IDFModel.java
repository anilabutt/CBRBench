package au.csiro.browser.rankingmodel.tf_Idf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import jdbm.PrimaryTreeMap;
import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.rankingmodel.bm25.BM25Calculator;
import au.csiro.browser.rankingmodel.structuralMetrices.DensityCalculator;
import au.csiro.browser.rankingmodel.vectorspace.DocNormCalculator;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;

public class TF_IDFModel {


	public ArrayList<ResultFormatter> getRankedClasses(Model model) {

   	 ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
   	 HashMap<String, Double> tf_IdfMap = new HashMap<String, Double>();
   			
   	 TfIdf_Data tfIdfClass = TfIdf_Data.getDefaultMap();
   	 PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
     
     Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
     Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
      
      ResIterator resourceIterator = model.listSubjectsWithProperty(label);
  
      while(resourceIterator.hasNext()){	
    	  Resource uri = resourceIterator.nextResource();
    	 // System.out.println(uri);
      	  NodeIterator nodeIterator = model.listObjectsOfProperty(uri, graphProperty);
      	  while(nodeIterator.hasNext()){
      		double tfIdf=0;
      		String node = nodeIterator.nextNode().toString();
      		if (corpus_tfIdf_Map.containsKey(node)) {
      			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(node);
      			if(ontologyTfIDFs.containsKey(uri.toString())) {
      				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(uri.toString());
      				//double tf= tfIdfs.get(1);
      				//double idf = tfIdfs.get(2);
      				//tfIdf = tf/idf;
      				tfIdf = tfIdfs.get(3);
      			} else { }
      		} else { }
      		
      		if (tf_IdfMap.containsKey(uri.toString())){
      			double value = tf_IdfMap.get(uri.toString());
      			if (value < tfIdf){
      				tf_IdfMap.put(uri.toString(), tfIdf);
      			}
      		} else {
      			tf_IdfMap.put(uri.toString(), tfIdf);
      			}
      	  }
      }
   		
      /*************************** Sort Hash map for tf_idf score **********************************/
      
      HashMap<String, Double> sortedtf_IdfMap = sortByValues(tf_IdfMap);
      
      /*********************************************************************************************/
     // ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
      
      for (Map.Entry<String, Double> entry : sortedtf_IdfMap.entrySet()) {
          	ResultFormatter result = new ResultFormatter();
          	String term = entry.getKey();
          	result.setTermIRI(term);
          	result.setGraphIRI("");
          	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
          	result.setScore(entry.getValue().toString());
          	resultList.add(result); 
          	
          //	System.out.println("" + term + "" + entry.getValue());
          	System.out.println("" + term + "");
      }
      
      return resultList;
	}

  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//System.out.println(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}
  	
  	 private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
}
