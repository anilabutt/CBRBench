package au.csiro.browser.rankingmodel.tf_Idf;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class TfIdf_Data {
	
	private static TfIdf_Data defaultMap;
	public PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map;
	public RecordManager recMan;

	
	public static TfIdf_Data getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new TfIdf_Data();
		}
		return defaultMap;
	}
	
	private TfIdf_Data(){
//		/home/ec2-user/www_exp
		String fileName = "/www_exp/data/rankings/tf_Idf/corpus_tf_Idf_database";
//		String fileName = "/home/ec2-user/www_exp/data/rankings/tf_Idf/corpus_tf_Idf_database";
		//System.out.println(fileName);
		try {
			recMan = RecordManagerFactory.createRecordManager(fileName);
			String recordName = "Corpus_termCount_ValueMap";
			corpus_tfIdf_Map = recMan.treeMap(recordName);
			//System.out.println("connection established :");
		} catch (IOException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		//	System.out.println("can not connect because of :" + e);
		}
	}
	
	public void save_tfIdf_Value(String ontologyId , HashMap<String, HashMap<Integer,Double>> ontologyTfIdfs) {
		// TODO Auto-generated method stub
		try {
			
			corpus_tfIdf_Map.put(ontologyId, ontologyTfIdfs);
		    recMan.commit();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> get_tfIdf_Value() {
		// TODO Auto-generated method stub
		return this.corpus_tfIdf_Map;
	}

	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
