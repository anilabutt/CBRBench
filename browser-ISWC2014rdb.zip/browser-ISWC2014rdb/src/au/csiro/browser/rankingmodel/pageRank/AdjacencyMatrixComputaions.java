package au.csiro.browser.rankingmodel.pageRank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Logger;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;
import jdbm.PrimaryTreeMap;
import au.csiro.browser.store.QuadStore;

public class AdjacencyMatrixComputaions {
	
	QuadStore store = QuadStore.getDefaultStore();
	private VirtGraph connection = store.getConnection();
	private Logger logger = Logger.getLogger(getClass().getName());
			
	public void createAdjacencyMatrix() {
		DomainAdjacencyMatrix classInstance = DomainAdjacencyMatrix.getDefaultMap();
 		PrimaryTreeMap<String, ArrayList<String>> adjacency_matrix_map = classInstance.get_domain_adjacency_matrix_map();
 		
 		try { 
 			ArrayList<String> graphs = this.getExistingLoadedOntology();
 		
 			for (int i=0; i<graphs.size(); i++){
 		
 			String graphIRI = graphs.get(i);
 			//String graphIRI = "http://purl.oclc.org/NET/ssnx/ssn";
 			//	logger.info("***************** Getting Values for Graph No"+ i +" : Graph URI is :"+graphIRI+"******************");
 				ArrayList<String> inlinks = this.getInlinks(graphIRI);
				classInstance.save_domain_adjacency_matrix_map(graphIRI, inlinks);
 				logger.info("inlinks :" + inlinks );
 				//inlinks.clear();
			}
 		}catch(Exception e){
 			logger.info(e.toString());
 		} finally { 		
 			classInstance.closeConnection();
 		}
	}
	
	public void createOutLinkMap() {
		OutLinksMap classInstance = OutLinksMap.getDefaultMap();
 		PrimaryTreeMap<String, Integer> outlink_map = classInstance.get_outlinks_map();
 		
 		try { 
 			ArrayList<String> graphs = this.getExistingLoadedOntology();
 		
 			for (int i=0; i<graphs.size(); i++){
 		
 				String graphIRI = graphs.get(i);
 				logger.info("***************** Getting Values for Graph No"+ i +" : Graph URI is :"+graphIRI+"******************");
 				int outlinkCount = this.getOutlinksCount(graphIRI);
				classInstance.save_outlinks_map(graphIRI, outlinkCount);
 				logger.info("outlinkCount :" + outlinkCount );
 				//inlinks.clear();
			}
 		}catch(Exception e){
 			logger.info(e.toString());
 		} finally { 		
 			classInstance.closeConnection();
 		}
	}
	
//	public void createAdjacencyMatrix() {
//
////		AdjacencyMatrix classInstance = AdjacencyMatrix.getDefaultMap();
//		DomainAdjacencyMatrix classInstance = DomainAdjacencyMatrix.getDefaultMap();
//		
// 	//	PrimaryTreeMap<String, HashMap<String, ArrayList<String>>> adjacency_matrix_map = classInstance.get_adjacency_matrix_map();
// 		PrimaryTreeMap<String, ArrayList<String>> adjacency_matrix_map = classInstance.get_domain_adjacency_matrix_map();
// 		
// 		/************************************************************************/
// 	
// 		try { 
// 			ArrayList<String> graphs = this.getExistingLoadedOntology();
// 		
// 			for (int i=250; i<500; i++){
// 				String graphIRI = graphs.get(i);
// 			//	HashMap<String,ArrayList<String>> ontologyAdjMap = new HashMap<String,ArrayList<String>>();
// 				logger.info("***************** Getting Values for Graph No"+ i +" : Graph URI is :"+graphIRI+"******************");
// 			
// 				ArrayList<String> classList = this.getClassList(graphIRI);
// 			
// 				for (int j=0; j<classList.size() ; j++){	 				
// 					String classIRI = classList.get(j);
// 					ArrayList<String> outlinkURIs = new ArrayList<String>();
// 					outlinkURIs = this.getProfile(graphIRI,classIRI);
////						ontologyAdjMap.put(classIRI, outlinkURIs);
// 					if (adjacency_matrix_map.containsKey(classIRI)) { 
// 						ArrayList<String> classes = new ArrayList<String>();
// 						classes = adjacency_matrix_map.get(classIRI);
// 						for (int count=0; count<outlinkURIs.size() ;count++) {
// 							if(classes.contains(outlinkURIs.get(count))){}
// 							else{
// 								classes.add(outlinkURIs.get(count));
// 							}
// 						}
// 						classInstance.save_domain_adjacency_matrix_map(classIRI, classes);
// 					} else {
// 						classInstance.save_domain_adjacency_matrix_map(classIRI, outlinkURIs);
// 					}
// 					
//		 				logger.info("ClassIRI is :" + classIRI +" Class count : " +j);
//		 				//logger.info("inlinks are : " + outlinkURIs.toString());
// 					outlinkURIs.clear();
// 				}
//
//// 				classInstance.save_adjacency_matrix_map(graphIRI, ontologyAdjMap);
//// 				
// 			}
// 		}catch(Exception e){
// 			logger.info(e.toString());
// 		} finally { 		
// 			classInstance.closeConnection();
// 		}
//}
//	public void createOutLinkMap() {
//
//		OutLinksMap classInstance = OutLinksMap.getDefaultMap();
//		PrimaryTreeMap<String, Integer> outlinkmap = classInstance.get_outlinks_map();
//		
// 		/************************************************************************/
// 	
// 		try { 
// 			ArrayList<String> graphs = this.getExistingLoadedOntology();
// 		
// 			for (int i=0; i<graphs.size(); i++){
// 				String graphIRI = graphs.get(i);
// 			//	HashMap<String,ArrayList<String>> ontologyAdjMap = new HashMap<String,ArrayList<String>>();
// 				logger.info("***************** Getting Values for Graph No"+ i +" : Graph URI is :"+graphIRI+"******************");
// 			
// 				ArrayList<String> classList = this.getClassList(graphIRI);
// 			
// 				for (int j=0; j<classList.size() ; j++){	 				
// 					String classIRI = classList.get(j);
// 					ArrayList<String> outlinkURIs = new ArrayList<String>();
// 					outlinkURIs = this.getProfile(graphIRI,classIRI);
////						ontologyAdjMap.put(classIRI, outlinkURIs);
// 					int count = outlinkURIs.size();
// 					if (outlinkmap.containsKey(classIRI)) { 
// 							count = count +  
// 						}
// 						classInstance.save_domain_adjacency_matrix_map(graphIRI, classes);
// 					} else {
// 						classInstance.save_domain_adjacency_matrix_map(graphIRI, outlinkURIs);
// 					}
// 					
//		 				//logger.info("ClassIRI is :" + classIRI);
//		 				//logger.info("inlinks are : " + outlinkURIs.toString());
// 					outlinkURIs.clear();
// 				}
//
//// 				classInstance.save_adjacency_matrix_map(graphIRI, ontologyAdjMap);
//// 				
// 			}
// 		}catch(Exception e){
// 			logger.info(e.toString());
// 		} finally { 		
// 			classInstance.closeConnection();
// 		}
//}
	
	
	public ArrayList<String> getClassList(String graphIRI){

  		ArrayList<String> classList = new ArrayList<String>();
  		
  		//logger.info("**************** SuperClass for concept " + concept + " **************** ");
  		
  		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
	            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
	            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
  				+ "SELECT DISTINCT ?subject "
  				+ "FROM <"+graphIRI+"> "
  				+ "WHERE {{{?subject rdf:type rdfs:Class} UNION {?subject rdf:type owl:Class.}} "
  				+ "FILTER (!isBlank(?subject))}";

			VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);
			
			try {
		    	  ResultSet results = vqe.execSelect(); 
		    	  while (results.hasNext()){
		    		  QuerySolution qs = results.nextSolution();
		    		  String uri = qs.getResource("subject").toString();
		    		  classList.add(uri);
		    	  }
			} catch(Exception e){
				logger.info(e +"");
			} finally {
				vqe.close();
			}
			//logger.info(classList.toString());
		return classList;
	}
	
	public ArrayList<String> getExistingLoadedOntology(){

		ArrayList<String> list = new ArrayList<String>();
		 
		String sparql = "SELECT DISTINCT ?graph "
				+ " WHERE {GRAPH ?graph {?subject ?property ?object}} ORDER BY (?graph)";
		 
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);

			ResultSet results = vqe.execSelect();
			try{
			while (results.hasNext()) {
				QuerySolution result = results.nextSolution();
			    String graph = result.get("graph").toString();
			    
			   // logger.info(graph);
			    list.add(graph);
			}     
	} catch(Exception e){
		logger.info(e +"");
	} finally {
		vqe.close();
	}
			return list;	         
	 }
	
	public ArrayList<String> getInlinks(String graphIRI){

		ArrayList<String> list = new ArrayList<String>();
		 
		String sparql = "SELECT DISTINCT ?graph "
				+ "FROM <http://browser.csiro.au/metadata> "
				+ "WHERE {?graph <http://www.w3.org/2002/07/owl#imports> <"+graphIRI+">}";
		 
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);

			ResultSet results = vqe.execSelect();
			try{
			while (results.hasNext()) {
				QuerySolution result = results.nextSolution();
			    String graph = result.get("graph").toString();
			    list.add(graph);
			}     
	} catch(Exception e){
		logger.info(e +"");
	} finally {
		vqe.close();
	}
			return list;	         
	}

	public int getOutlinksCount(String graphIRI){

		String sparql = "SELECT (count(DISTINCT ?graph) as ?count) "
				+ "FROM <http://browser.csiro.au/metadata> "
				+ "WHERE {<"+graphIRI+"> <http://www.w3.org/2002/07/owl#imports> ?graph}";
		 
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);

			ResultSet results = vqe.execSelect();
			int count =0;
			try{
			while (results.hasNext()) {
				QuerySolution result = results.nextSolution();
			    count = Integer.parseInt(result.get("count").toString().split("\\^")[0]);
			 //   list.add(count);
			}     
	} catch(Exception e){
		logger.info(e +"");
	} finally {
		vqe.close();
	}
			return count;	         
	}

    
    public ArrayList<String> getProfile(String graphIRI,String uri) {
    	ArrayList<String> outlinkURIs = new ArrayList<String>(); 
  
   	 String sparql ="PREFIX csiro:<http://au.csiro.browser#>" +
        "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
        "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
        "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
      
		" SELECT DISTINCT ?domain "
		+" FROM <"+graphIRI+"> "
        + "WHERE {"
        	+ "{"
        		+ "{?domain rdfs:subClassOf+ ?res. "
        		+ "?res owl:onProperty ?property.} "
        		+ "UNION "
        		+ "{"
        			+ "{?domain rdfs:subClassOf+ ?class. "
        			+ "?property rdfs:domain ?class.} "
        			+ "UNION "
        			+ "{?property rdfs:domain ?domain}"
        		+ "} "
        		+ "?property rdf:type owl:ObjectProperty."
        	+ "}"
        	+ "{"
        		+ "{?res ?resProp <"+uri+">."
        		+ "FILTER ((?resProp = owl:allValuesFrom) || (?resProp = owl:someValuesFrom) || (?resProp = owl:hasValue) )} "
        		+ "UNION "
        		+ "{?property rdfs:range <"+uri+">.}"
            	+ "{{?domain rdf:type rdfs:Class} UNION {?domain rdf:type owl:Class}}"
        	+ " FILTER (!isBlank(?domain))} "
        	+ "}";
  	
//    	 String sparql ="PREFIX csiro:<http://au.csiro.browser#>" +
//    		        "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
//    		        "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
//    		        "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
//    		      
//    				" SELECT DISTINCT ?range "
//    				+" FROM <"+graphIRI+"> "
//    		        + "WHERE {"
//    		        	+ "{"
//    		        		+ "{<"+uri+"> rdfs:subClassOf+ ?res. "
//    		        		+ "?res owl:onProperty ?property.} "
//    		        		+ "UNION "
//    		        		+ "{"
//    		        			+ "{<"+uri+"> rdfs:subClassOf+ ?class. "
//    		        			+ "?property rdfs:domain ?class.} "
//    		        			+ "UNION "
//    		        			+ "{?property rdfs:domain <"+uri+">}"
//    		        		+ "} "
//    		        		+ "?property rdf:type owl:ObjectProperty."
//    		        	+ "}"
//    		        	+ "{"
//    		        		+ "{?res ?resProp ?range."
//    		        		+ "FILTER ((?resProp = owl:allValuesFrom) || (?resProp = owl:someValuesFrom) )} "
//    		        		+ "UNION "
//    		        		+ "{?property rdfs:range ?range.}"
//    		            	+ "{{?range rdf:type rdfs:Class} UNION {?range rdf:type owl:Class}}"
//    		        	+ " FILTER (!isBlank(?range))} "
//    		        	+ "}";
    	 
//    	 String query = "SELECT DISTINCT ?range FROM <"+graphIRI+"> "
//    	 		+ "WHERE { "
//    	 		+ "{ {<"+uri+"> rdfs:subClassOf+ ?res. ?res owl:onProperty ?property.} "
//    	 			+ " UNION "
//    	 			+ "{ {<"+uri+"> rdfs:subClassOf+ ?class. ?property rdfs:domain ?class.}"
//    	 				+ " UNION "
//    	 				+ "{?property rdfs:domain <"+uri+">} "
//    	 			+ "} "
//    	 		+ " ?property rdf:type owl:ObjectProperty.} "
//    	 		+ "{{?res ?resProp ?range."
//    	 		+ "FILTER ((?resProp = owl:allValuesFrom) || (?resProp = owl:someValuesFrom) )} UNION {?property rdfs:range ?range.}"
//    	 		+ "{{?range rdf:type rdfs:Class} UNION {?range rdf:type owl:Class}} FILTER (!isBlank(?range))} }";
    //	 logger.info(sparql);
    	 VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);

    	 try{
			ResultSet results = vqe.execSelect();
			while (results.hasNext()) {
				QuerySolution result = results.nextSolution();
			    String range = result.get("domain").toString();
		//	     logger.info(range);
			    outlinkURIs.add(range);
			}
    	 } catch(Exception e){
    		 logger.info(e.toString());
    	 } finally {
    		 vqe.close();
    	 }
    	 
    	return outlinkURIs;    	
    }

}
