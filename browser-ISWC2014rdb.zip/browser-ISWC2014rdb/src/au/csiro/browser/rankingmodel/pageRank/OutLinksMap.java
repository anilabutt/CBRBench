package au.csiro.browser.rankingmodel.pageRank;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class OutLinksMap {
	
	private static OutLinksMap defaultMap;
	
	private PrimaryTreeMap<String,Integer> outlinks_map;
	
	private RecordManager recMan;

	public static OutLinksMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new OutLinksMap();
		}
		return defaultMap;
	}
	
	public OutLinksMap(){
		
		String fileName = "/www_exp/data/rankings/pagerank/outlinks_map_database";
	//	String fileName = "/home/u5096831/outlinks_map_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileName);
			String recordName = "outlinks_map_table";
			outlinks_map = recMan.treeMap(recordName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void save_outlinks_map(String sourceClass , int outlinks) {
		// TODO Auto-generated method stub
		try {
			
			outlinks_map.put(sourceClass, outlinks);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String,Integer> get_outlinks_map() {
		return this.outlinks_map;
	}

	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
