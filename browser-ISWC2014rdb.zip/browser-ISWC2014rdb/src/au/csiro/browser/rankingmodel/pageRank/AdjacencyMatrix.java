package au.csiro.browser.rankingmodel.pageRank;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class AdjacencyMatrix {
	
	private static AdjacencyMatrix defaultMap;
	
	private PrimaryTreeMap<String,HashMap<String,ArrayList<String>>> adjacency_matrix_map;
	
	private RecordManager recMan;

	public static AdjacencyMatrix getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new AdjacencyMatrix();
		}
		return defaultMap;
	}
	
	public AdjacencyMatrix(){
		
		String fileName = "/www_exp/data/rankings/pagerank/adjacency_matrix_map_database";
//		String fileName = "/usr/local/data/rankings/pagerank/adjacency_matrix_map_database";
	//	String fileName = "/home/u5096831/adjacency_matrix_map_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileName);
			String recordName = "adjacency_matrix_map_table";
			adjacency_matrix_map = recMan.treeMap(recordName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void save_adjacency_matrix_map(String sourceClass , HashMap<String,ArrayList<String>> outlinks) {
		// TODO Auto-generated method stub
		try {
			
			adjacency_matrix_map.put(sourceClass, outlinks);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String,HashMap<String,ArrayList<String>>> get_adjacency_matrix_map() {
		return this.adjacency_matrix_map;
	}

	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
