package au.csiro.browser.rankingmodel.pageRank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.logging.Logger;

import jdbm.PrimaryTreeMap;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;
import au.csiro.browser.rankingmodel.structuralMetrices.BetweenessMeasureCal;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;

public class PageRank {

	private static double damping_factor = 0.85; 
	private long total_num_nodes= 0;
	private double threshold=0.01;
	
	private Logger logger;
	private PageRankMap initialMapClass;
	private DomainAdjacencyMatrix adjacency_matrix_class;
	private PrimaryTreeMap<String, Double> rank_value_table;
	private PrimaryTreeMap<String, ArrayList<String>> adjacency_matrix;
	private OutLinksMap outlinkCount;
	private PrimaryTreeMap<String, Integer> outlinks ;
	private TfIdf_Data tfIdfClass= TfIdf_Data.getDefaultMap();
  	private PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
	
	public PageRank(){
		
		logger = Logger.getLogger(getClass().getName());
		
		initialMapClass =  PageRankMap.getDefaultMap();
		rank_value_table = initialMapClass.get_tf_Idf_map();
		
		adjacency_matrix_class  = DomainAdjacencyMatrix.getDefaultMap();
		adjacency_matrix =  adjacency_matrix_class.get_domain_adjacency_matrix_map();
		
		outlinkCount = OutLinksMap.getDefaultMap();		
		outlinks = outlinkCount.get_outlinks_map();
		
		total_num_nodes = initialMapClass.getTotalNumberOfNodes();
		
		logger.info(" total_num_nodes : " + total_num_nodes);
	}

	public ArrayList<ResultFormatter> getRankedClasses(Model model, ArrayList<String> queryWords){

		
	   	 ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
	   	 HashMap<String, Double> tf_IdfMap = new HashMap<String, Double>();
	   			
	   	 TfIdf_Data tfIdfClass = TfIdf_Data.getDefaultMap();
	   	 PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
	     
	     Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
	     Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
	      
	      ResIterator resourceIterator = model.listSubjectsWithProperty(label);
	  
	      while(resourceIterator.hasNext()){	
	    	  Resource uri = resourceIterator.nextResource();
	    	 // System.out.println(uri);
	      	  NodeIterator nodeIterator = model.listObjectsOfProperty(uri, graphProperty);
	      	  while(nodeIterator.hasNext()){
	      		double tfIdf=0;
	      		String node = nodeIterator.nextNode().toString();
	      		double graphRank = rank_value_table.get(node);
	      		if (corpus_tfIdf_Map.containsKey(node)) {
	      			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(node);
	      			if(ontologyTfIDFs.containsKey(uri.toString())) {
	      				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(uri.toString());
	      				tfIdf = tfIdfs.get(3);
	      			} else { }
	      		} else { }
	      		
	      		if (tf_IdfMap.containsKey(uri.toString())){
	      			double value = tf_IdfMap.get(uri.toString());
	      			if (value < tfIdf){
	      				tf_IdfMap.put(uri.toString(), tfIdf+ graphRank);
	      			}
	      		} else {
	      			tf_IdfMap.put(uri.toString(), tfIdf+ graphRank);
	      			}
	      	  }
	      }
	      /*************************** Sort Hash map for tf_idf score **********************************/
	      
	      HashMap<String, Double> sortedtf_IdfMap = sortByValues(tf_IdfMap);
	      
	      /*********************************************************************************************/
	     // ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
	      
	      for (Map.Entry<String, Double> entry : sortedtf_IdfMap.entrySet()) {
	        	
	        	//ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(entry.getKey().toString()));
	           // HashMap<String, Double> resourceMap = new HashMap<String, Double>();   
	            //while(uriIterator.hasNext()){
	            	ResultFormatter result = new ResultFormatter();         	
	            	String term = entry.getKey();
	            	result.setTermIRI(term);
	            	result.setGraphIRI(entry.getKey().toString());
	            	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
	            	result.setScore(entry.getValue().toString());
	            	resultList.add(result);
	            	System.out.println("" + term + "" + entry.getValue());
           
	            
	        } 
	      	  return resultList;
	}
 	
 	private TF_IDFHolder getTF_IDFValues(String term, String graphIRI){
 		//System.out.println("TERMS " + term +" GRAPHS " + graphIRI );
 		TF_IDFHolder tf_IdfHolder = new TF_IDFHolder();
 		
 		  double tf = 0;
		  double idf = 0;
		  double tf_idf = 0;
		  
		  if (corpus_tfIdf_Map.containsKey(graphIRI)) {
    			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(graphIRI);
    			if(ontologyTfIDFs.containsKey(term)) {
    				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(term);
    		  		tf = tfIdfs.get(1);
    				idf = tfIdfs.get(2);
    				tf_idf = tfIdfs.get(3);
    			}
    		}
	  
		  	tf_IdfHolder = new TF_IDFHolder(tf, idf, tf_idf);    
		  	return tf_IdfHolder;
 	}
	public void calculatePageRank() {
		/******************************************************************************
		 * Pre-calculations 
		 * ****************************************************************************/
		
//		PageRankTF_IDFMap tf_idfPageRankMap = new PageRankTF_IDFMap();
//		tf_idfPageRankMap.initializePageRankScore();	
//		AdjacencyMatrixComputaions adjacency_matrix_com  = new AdjacencyMatrixComputaions();	
//		adjacency_matrix_com.createAdjacencyMatrix();
	
		/******************************************************************************
		 * Get Total number of nodes in corpus 
		 * ****************************************************************************/
	//	PageRankMap initialMapClass =  PageRankMap.getDefaultMap();
//		
//		total_num_nodes = initialMapClass.getTotalNumberOfNodes();
//		logger.info(" total_num_nodes : " + total_num_nodes);
		
		/******************************************************************************
		 * Initialize page rank table to store URLs and their page ranks as a key value pair
		 * ****************************************************************************/
		
		//TF_IDFMap initialMapClass =  TF_IDFMap.getDefaultMap();
		//rank_value_table = initialMapClass.get_tf_Idf_map();
		//logger.info(" total_num_nodes : " + total_num_nodes);
		
		
		/******************************************************************************
		 * Initialize page rank table to store URLs and their page ranks as a key value pair
		 * ****************************************************************************/
		
//		AdjacencyMatrix adjacency_matrix_class  = AdjacencyMatrix.getDefaultMap();
//		adjacency_matrix =  adjacency_matrix_class.get_adjacency_matrix_map();
		
//		String key="";
//		long count=0;
//		for (Map.Entry<String, HashMap<String,ArrayList<String>>> entry : adjacency_matrix.entrySet()) {
//			HashMap<String,ArrayList<String>> ontologyAdjacencyMap = entry.getValue();
//			for(Map.Entry<String, ArrayList<String>> ontologyEntry: ontologyAdjacencyMap.entrySet()){
//				key= entry.getKey();
//				count++;
//			}
//		}
//		
//		
//		logger.info(key);
//		logger.info(count+"");
		/******************************************************************************
		 * 
		 * Temporary hash map to store previous values of (key,value) pair.
		 * In successive iteration, it will compare those values with current value of page rank for all the nodes.
		 * When this difference goes below threshold value, it will break out of while loop.
		 * 
		 * ****************************************************************************/
		
	//	HashMap<String, Double> rank_values_table_temp =new HashMap<String, Double>();

		//Initialization of temporary hash map table

		/******************************************************************************
		 * algorithm execution. It stops execution once convergence has occurred for given corpus
		 * ****************************************************************************/
		int iteration=50;
		while(iteration>0){
		//	while(iteration<2){
			iteration--;
			logger.info(" this is iteration number  : " + iteration);
			/*Following code store the stale value of page rank in a hashmap rank_values_table before it calls the function join_rvt_am. 
			 * These values are then compared against new page rank values in rank_values_table after this function has finished execution
			*/
			double stale_pagerank_sum = 0.0;
			double current_pagerank_sum= 0.0;
			
			for(Map.Entry<String, Double> entry: rank_value_table.entrySet()) {				
//				String classIRI = entry.getKey();
//				Double value = entry.getValue();
//				rank_values_table_temp.put(classIRI, value);
				stale_pagerank_sum+=entry.getValue();
			}
			
			logger.info(" stale_pagerank_sum : " + stale_pagerank_sum);
			/* Call to join_rvt_am to calculate page rank values for input URIs based upon page rank value of preceeding URIs.
			 * this function will get called until convergence */
		//	logger.info("***** Before rvt table call ******");
			join_rvt_am();
		//	logger.info("***** end rvt table call ******");
	
			/* Threshold determines the estimate by which current and previous page ranks vary. 
			 * Value of threshold determines stopping condition.
			 * low value of page rank increases execution time. But gives excellent final result.
			 * High page rank value decreases execution time, but gives poor results of page rank calculation */
				
			 double difference=0.0;


			/* Loop calculates difference between current and old page rank value for each URL.
			 * Sum of difference of all the URLs is compared against predefined Threshold value. 
			 * When this difference goes below threshold, Loop breaks out */

			for(Map.Entry<String, Double> entry: rank_value_table.entrySet()) {
					current_pagerank_sum+=entry.getValue();
			}
			logger.info(" current_pagerank_sum : " + current_pagerank_sum);
			
			difference = current_pagerank_sum - stale_pagerank_sum;
			
			
			logger.info(" difference : " + difference);
			if(difference<threshold) {
				break;
			}	else {
				
			}	
		}
		
		/**********************************************
		 * Now store these values to the disk
		 * *******************************************/
	}
	
	/*************************************************************************
	 * Function to calculate page rank value for the list of all input URLs
	 * This is an iterative process until convergence. 
	 * Once convergence occurs, that is there is no difference between current 
	 * and earlier values of page rank, this method will no longer be called
	 * ************************************************************************/
    
	public void join_rvt_am(){
	

		ArrayList<String> inlink_list=new ArrayList<String>();
		
		LinkedHashMap<String,Double> intermediate_rvt = new LinkedHashMap<String,Double>();
		
		
		/*intermediate_rvt_iter hashmap stores pagerank values for dangling nodes 
		 * along with page rank values of its successor nodes weighed by their outbound links */
		
		for(Map.Entry<String, Double> entry: rank_value_table.entrySet()) {		
			String graphIRI = entry.getKey();
			intermediate_rvt.put(graphIRI, 0.0);
		}
		
		String source_url="";
		int inlinkCount=0;
		String inlink_url="";
		double intermediate_rank_value=0.0;
		double dangling_value=0;
		double dangling_value_per_page=0.0;

		/* Iterate over all the URLs in given input file */
		
		int ontologycount=1;
		
			Iterator<String> ite=adjacency_matrix.keySet().iterator();
			
			while(ite.hasNext()) {
			
			source_url= ite.next();
			inlink_list=adjacency_matrix.get(source_url);
			inlinkCount=inlink_list.size();
			
			
			/* Assign updated page rank value to all the successors of current node 
			 * Page rank value is equal to page rank value of predecessor node 
			 * weighed by the number of its outbound links */
			
			
				for(int i=0;i<inlinkCount;i++)	{
					inlink_url=inlink_list.get(i);
					intermediate_rank_value = 	intermediate_rank_value + (rank_value_table.get(inlink_url)/ (outlinks.get(inlink_url)));
					//intermediate_rank_value=intermediate_rvt.get(target_url)+((rank_value_table.get(source_url))/(inlinkCount));
					intermediate_rvt.put(source_url,intermediate_rank_value);
				}
			
			/* Special case for dangling node with no outbound link */
			
				if(outlinks.get(source_url)==0) {
					dangling_value+=rank_value_table.get(source_url);
				}
		}
		
		dangling_value_per_page= dangling_value /(double)total_num_nodes;
		
		logger.info("dangling_value_per_page " + dangling_value_per_page);
		
		/*Page rank of all the dangling links is calculated and is distributed among all the webpages to minimize effect of dangling nodes.
		 * Without this facility, average page rank of given graph will be less than 1 with poor utilization */

			for(Map.Entry<String, Double> entry: rank_value_table.entrySet()) {	
				String key = entry.getKey();
				double value = intermediate_rvt.get(key) + dangling_value_per_page;
				intermediate_rvt.put(key, value);
			//	rank_value_table.put(key, value);		
			//	initialMapClass.save_tf_Idf_map(key, value);
			}
			
			System.out.println(" intermediate_rvt value updated : ");
			//initialMapClass.commitValues();
		
		/*Final page rank value for given page for given number of iteration. 
		 * Page rank is caluclated by considering two scenarios, first is random surfer 
		 * model and second is the possibility that surfer might reach particual page 
		 * after clicking specific number of URLs in the given pool */
		
		for(Map.Entry<String, Double> entry: rank_value_table.entrySet()) {	
			double value =damping_factor*intermediate_rvt.get(entry.getKey())+((1-damping_factor)*((1.0)/(double)total_num_nodes));
		//	System.out.println(" new value of " + entry.getKey() + " : " + value);
			initialMapClass.save_tf_Idf_map(entry.getKey(),value);
		}
		//initialMapClass.commitValues();
	}

	

 	
  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//logger.info(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}
	
  	
	  private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
	  

	
}
