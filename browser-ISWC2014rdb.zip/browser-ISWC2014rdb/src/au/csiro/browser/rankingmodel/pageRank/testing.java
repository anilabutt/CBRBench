package au.csiro.browser.rankingmodel.pageRank;

import java.util.ArrayList;

import jdbm.PrimaryTreeMap;

public class testing {

	public static void main(String[] args)  {
		
		PageRankTF_IDFMap tf_idfPageRankMap = new PageRankTF_IDFMap();
		AdjacencyMatrixComputaions adjacency_matrix_com  = new AdjacencyMatrixComputaions();
		
		
		/******************************************************************************
		 * Pre-calculations 
		 * ****************************************************************************/
		
 		//tf_idfPageRankMap.calculateInitialPageRankScore();
 		
		//AdjacencyMatrix adjacency_matrix_class  = AdjacencyMatrix.getDefaultMap();
		adjacency_matrix_com.createAdjacencyMatrix();
		
//		PrimaryTreeMap<String, ArrayList<String>> adjacency_matrix =  adjacency_matrix_class.get_adjacency_matrix_map();
		
	//	TF_IDFMap classInstance =  TF_IDFMap.getDefaultMap();
		
//		PageRank pp = new PageRank();
//		pp.getRankedClasses();
		
//		long total_num_nodes = adjacency_matrix.size();
//		
//		System.out.println(" total_num_nodes : " + total_num_nodes); 
//		System.out.println(adjacency_matrix.get("http://www.w3.org/ns/prov#Entity")); 
	}
}
