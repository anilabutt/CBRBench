package au.csiro.browser.rankingmodel.random;

import java.util.ArrayList;

import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;

public class BooleanModel {

	
  	public ArrayList<ResultFormatter> getRankedProperties(Model model) {

   		ArrayList<ResultFormatter> rf = new ArrayList<ResultFormatter>();
   		
   		System.out.println("In boolean ");
   		
        Property props = model.getProperty("http://www.biomeanalytics.com/model/orthoOntology.owl#hasProperty");
        Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
        Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
        NodeIterator propertyIterator = model.listObjectsOfProperty(props);
        
        while(propertyIterator.hasNext()){
        	System.out.println("In while ");
        	ResultFormatter rsf = new ResultFormatter();
        	String propertyURI = propertyIterator.next().toString();
        	        	
        	//getLabel of property
        	Resource property = model.getResource(propertyURI);
        	NodeIterator labelIterator = model.listObjectsOfProperty(property,label);
        	
        	String propLabel="";
        	
        	if (labelIterator.hasNext()){
        	RDFNode pLabel = labelIterator.nextNode();
        	propLabel = pLabel.toString();
        	//System.out.println(propLabel + "is property Label");
        		if(propLabel.contains("@")) {
        			propLabel=propLabel.split("@")[0];
        		} 
        		if (propLabel.contains("^")){
        			propLabel= propLabel.split("\\^")[0];
        		}
        	} else {
        		propLabel = propertyURI;
        	}
        	
        	//NodeIterator nodeIterator = model.listObjectsOfProperty(arg0)
        	rsf.setGraphIRI("");
   		  	rsf.setTermIRI(propertyURI);
   		  	rsf.setTermLabel(propLabel);
   		  	rsf.setScore("");
   		  	rf.add(rsf);
        }
        
      return rf;
 	}
  	
  	
  	public ArrayList<ResultFormatter> getRankedClasses(Model model) {

   		ArrayList<ResultFormatter> rf = new ArrayList<ResultFormatter>();
   		
        Property props = model.getProperty("http://www.biomeanalytics.com/model/orthoOntology.owl#hasProperty");
        Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
        Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
//        NodeIterator graphIterator = model.listObjectsOfProperty(graphProperty);
//        
//        
//        while(graphIterator.hasNext()){
//        	String graphIRI = graphIterator.next().toString();
//        	
//        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graphIRI));
//            
//            while(uriIterator.hasNext()){
//            	ResultFormatter result = new ResultFormatter();
//            	//String uri = uriIterator.next().toString();
//            	String term = uriIterator.next().toString();
//            	result.setTermIRI(term);
//            	result.setGraphIRI(graphIRI);
//            	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
//            	result.setScore("");
//            	rf.add(result);
//              	System.out.println(" Term " + term  );
//            }            
//        	//graphList.add(uri);
//        }

        ResIterator propertyIterator = model.listSubjectsWithProperty(graphProperty);
        
        while(propertyIterator.hasNext()){
        	ResultFormatter rsf = new ResultFormatter();
        	String propertyURI = propertyIterator.next().toString();
        	        	
        	//getLabel of property
        	Resource property = model.getResource(propertyURI);
        	NodeIterator labelIterator = model.listObjectsOfProperty(property,label);
        	
        	String propLabel="";
        	
        	if (labelIterator.hasNext()){
        	RDFNode pLabel = labelIterator.nextNode();
        	propLabel = pLabel.toString();
        	//System.out.println(propLabel + "is property Label");
        		if(propLabel.contains("@")) {
        			propLabel=propLabel.split("@")[0];
        		} 
        		if (propLabel.contains("^")){
        			propLabel= propLabel.split("\\^")[0];
        		}
        	} else {
        		propLabel = propertyURI;
        	}
        	 
        	rsf.setGraphIRI("");
   		  	rsf.setTermIRI(propertyURI);
   		  	rsf.setTermLabel(propLabel);
   		  	rsf.setScore("");
   		  	rf.add(rsf);
   		  	System.out.println(propertyURI);
        }
        
      return rf;
 	}
  	
  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//System.out.println(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}
}
