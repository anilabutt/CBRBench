package au.csiro.browser.rankingmodel.structuralMetrices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.logging.Logger;

import jdbm.PrimaryTreeMap;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;

import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;

public class ClassMatchMeasure {

	//DocNormCalculator diskmap = new DocNormCalculator();
//	LocalQuadStore store = LocalQuadStore.getDefaultStore();
	
//private VirtGraph connection = store.getConnection();
	private double exactMatchConstant = 0.6;
	private double partialMatchConstant = 0.4;
 	private Logger logger = Logger.getLogger(getClass().getName());
 	TfIdf_Data tfIdfClass= TfIdf_Data.getDefaultMap();
  	private PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
  	
 	
	public ArrayList<ResultFormatter> getRankedClasses(Model model, ArrayList<String> queryString) {

   		List<String> graphList = new ArrayList<String>();
   		HashMap<String, Double> ClassMatchScore = new HashMap<String, Double>();
        

        Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
        Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
        /********************  Get All graphs in the Result Set *****************************/
        
        NodeIterator graphIterator = model.listObjectsOfProperty(graphProperty);
        
        while(graphIterator.hasNext()){
        	String uri = graphIterator.next().toString();
        	graphList.add(uri);
        }
        
       // logger.info("Graph List : " + graphList);
 
        /*********************** Calculate BM25 Value for each graph ***********************************/
        
        for (int i=0; i<graphList.size() ; i++){
        	
        	String graphIRI = graphList.get(i);
        	
        //	logger.info(" /********** "+graphIRI +" *********/");
        	int exactMatchScore = getExactMatchCount(model, graphIRI, queryString);
        	int partialMatchScore = getPartialMatchCount(model, graphIRI, queryString) - exactMatchScore;
         	
        	double classMatchScore = ((exactMatchScore * exactMatchConstant) + (partialMatchScore * partialMatchConstant));
        //	logger.info("class match score " + classMatchScore);
        	ClassMatchScore.put(graphIRI, classMatchScore);       	
        }
        
        /*************************** Sort Hash map for bm25 score **********************************/
      
        HashMap<String, Double> sortedClassMatchScoreMap = sortByValues(ClassMatchScore);
        ArrayList<String> _temp = new ArrayList<String>();  
        
        /************************** put sorted values into  ArrayList *******************************/
        ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
       
        for (Map.Entry<String, Double> entry : sortedClassMatchScoreMap.entrySet()) {
        	
	String graph = entry.getKey().toString(); 
        	
//        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graph));  	
        	
//        	HashMap<String, Double> sorted = new HashMap<String, Double>();
//        	HashMap<String, Double> map = new HashMap<String, Double>();
//        	
//        	while(uriIterator.hasNext()){
//        		String term = uriIterator.next().toString();
//        		if(_temp.contains(term)) { }
//            	else {
//            	    _temp.add(term);
//            	    TF_IDFHolder holder = new TF_IDFHolder();
//            	    holder = getTF_IDFValues(term, graph);
//            	    double tfIdf = holder.getTF_IDF();
//            	    map.put(term, tfIdf);   
//            	    }     		
//        	}
//        	
//        	sorted = this.sortByValues(map);
//        	
//        	for (Map.Entry<String, Double> entry2 : sorted.entrySet()) { 
//        		ResultFormatter result = new ResultFormatter();
//        		String term = entry2.getKey();
//            	result.setTermIRI(term);
//            	result.setGraphIRI(graph);
//            	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
//            	result.setScore(entry.getValue().toString());
//            	resultList.add(result);
//            	System.out.println("" + term + "" + entry.getValue());
//        	}
//        
//        }
        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(entry.getKey().toString()));
            HashMap<String, Double> resourceMap = new HashMap<String, Double>();   
            while(uriIterator.hasNext()){
            	ResultFormatter result = new ResultFormatter();
            	String term = uriIterator.next().toString();
               	if(_temp.contains(term)) { }
            	else {
            	    _temp.add(term);

            	    result.setTermIRI(term);
                	result.setGraphIRI(entry.getKey().toString());
                	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
                	result.setScore(entry.getValue().toString());
                	resultList.add(result);
                 	System.out.println(" Term " + term + " Score " + entry.getValue().toString() );
                 // 	System.out.println(term);
            	}
            	
            }
            
           
            
        } 
        
        return resultList;
 	}
	private TF_IDFHolder getTF_IDFValues(String term, String graphIRI){
		//System.out.println("TERMS " + term +" GRAPHS " + graphIRI );
		TF_IDFHolder tf_IdfHolder = new TF_IDFHolder();
		
		  double tf = 0;
	  double idf = 0;
	  double tf_idf = 0;
	  
	  if (corpus_tfIdf_Map.containsKey(graphIRI)) {
			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(graphIRI);
			if(ontologyTfIDFs.containsKey(term)) {
				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(term);
		  		tf = tfIdfs.get(1);
				idf = tfIdfs.get(2);
				tf_idf = tfIdfs.get(3);
			}
		}
  
	  	tf_IdfHolder = new TF_IDFHolder(tf, idf, tf_idf);    
	  	return tf_IdfHolder;
	}
 	public int getExactMatchCount(Model model, String graphIRI, ArrayList<String> queryString){
 		int result = 0;
 		String term="";
 		if(queryString.size() != 0 )
 			term = queryString.get(0);
 		
 		String query1="PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"
 				+ "SELECT ?uri "
 				+ "WHERE { "
 				+ "?uri rdfs:label ?label."
 				+ "?uri rdfs:graph <"+graphIRI+">."
 				+ "FILTER  regex(str(?label), \"^"+ term +"$\", \"i\")";		
 		
 		String query2 = "";
 		
 		for(int i=1; i<queryString.size(); i++){
 			query2 = query2 + " || (str(?label) =\""+ queryString.get(i).toLowerCase() +"\")";
 			
 		}
 		
 		String query3 = "}";
 		
 		String query = query1 + query2 + query3;
 		//logger.info(query);
 		try {
 	 		  QueryExecution exec = QueryExecutionFactory.create(query, model);
	    	  ResultSet resultset = exec.execSelect();	
	    	//  logger.info("*********** Exact Match ******** ");
	    	  while (resultset.hasNext()){
	    		  QuerySolution qs = resultset.nextSolution();
	    		  logger.info(qs.get("uri").toString());
	    		  result++;
	    		  // result = Integer.parseInt(qs.getLiteral("count").toString().split("\\^")[0]);		  
	    	  }
 		 }catch(Exception e){
 			 logger.info(query);
 			 logger.info(e+"");
 		 }		
 		return result;
 	}
 		
	public int getPartialMatchCount(Model model, String graphIRI, ArrayList<String> queryString){
 		int result = 0;
 		String term="";
 		if(queryString.size() != 0 )
 			term = queryString.get(0);
 		
 		String query1="SELECT ?uri "
 				+ "WHERE { "
 				+ "?uri <http://www.w3.org/2000/01/rdf-schema#label> ?label."
 				+ "?uri <http://www.w3.org/2000/01/rdf-schema#graph> <"+graphIRI+">."
 				//+ "FILTER regex(?label, \""+ term +"\", \"i\")"
 				+ "FILTER ( (regex(str(?label), \""+ term.toLowerCase() +"\", \"i\"))";
 		
 		
 		String query2 = "";
 		
 		for(int i=1; i<queryString.size(); i++){
 			query2 = query2 + " || (regex(str(?label), \""+ queryString.get(i).toLowerCase() +"\", \"i\"))";
 			
 		}
 		
 		String query3 = ")}";
 		
 		String query = query1 + query2 + query3;
 		QueryExecution exec = QueryExecutionFactory.create(query, model);
 		 try {
	    	  ResultSet resultset = exec.execSelect();
	    	//  logger.info("*********** Partial Match ******** ");
	    	  while (resultset.hasNext()){
	    		  QuerySolution qs = resultset.nextSolution();
	    		 // logger.info(qs.get("uri").toString());
	    		  result++;		  
	    	  }
 		 }catch(Exception e){
 			 logger.info(e+"");
 		 }		
 		return result;
 	}
 		
  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//logger.info(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}
	
  	
	  private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
	 
	  public HashMap<String, Double> getClassMatchMeasure(ArrayList<String> graphList, Model model, ArrayList<String> queryString){
		    HashMap<String, Double> ClassMatchScore = new HashMap<String, Double>();
		     //   DensityCalculator densityCal = new DensityCalculator();
		      //  densityCal.saveDensityforCorpus();
		    Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
	  for (int i=0; i<graphList.size() ; i++){
      	
      	String graphIRI = graphList.get(i);
      	
      //	logger.info(" /********** "+graphIRI +" *********/");
      	int exactMatchScore = getExactMatchCount(model, graphIRI, queryString);
      	int partialMatchScore = getPartialMatchCount(model, graphIRI, queryString) - exactMatchScore;
       	
      	double classMatchScore = ((exactMatchScore * exactMatchConstant) + (partialMatchScore * partialMatchConstant));
      //	logger.info("class match score " + classMatchScore);
      	ClassMatchScore.put(graphIRI, classMatchScore);       	
      }
	  return ClassMatchScore;
	  }
}
