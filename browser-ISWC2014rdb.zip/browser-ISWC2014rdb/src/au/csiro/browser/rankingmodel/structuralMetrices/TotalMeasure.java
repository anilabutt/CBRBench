package au.csiro.browser.rankingmodel.structuralMetrices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import jdbm.PrimaryTreeMap;
import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.rankingmodel.vectorspace.QueryVector;
import au.csiro.browser.store.QuadStore;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
public class TotalMeasure {

	 
    public HashMap<String, Double> classMatchMeasureScore = new HashMap<String, Double>();
    public HashMap<String, Double> betweennessMeasureScore = new HashMap<String, Double>();
    public HashMap<String, Double> semanticSimilarityMeasureScore = new HashMap<String, Double>();
    public HashMap<String, Double>  densityMeasureScore =new HashMap<String, Double>();
    public HashMap<String, Double>  totalScore =new HashMap<String, Double>();
    
//	Model ontology = ModelFactory.createDefaultModel();
		
		public TotalMeasure(){
			
		}
		
	public ArrayList<ResultFormatter> getRankedClasses(Model model, ArrayList<String> queryString) {

		 ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
	       ClassMatchMeasure cmm = new ClassMatchMeasure();
	       BetweennessMeasure bm = new BetweennessMeasure();
	       SemanticSimilarityMeasure ssm = new SemanticSimilarityMeasure();
	       DensityMeasure dm = new DensityMeasure();
		
	//	BetweenessMeasureCal btw = new BetweenessMeasureCal();
//		btw.calculatePaths();
   		ArrayList<String> graphList = new ArrayList<String>();
   	//	HashMap<String, Double> betweennessMeasure = new HashMap<String, Double>();
        
   		Property props = model.getProperty("http://www.biomeanalytics.com/model/orthoOntology.owl#hasProperty");
        Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
        Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
        /********************  Get All graphs in the Result Set *****************************/
        
        NodeIterator graphIterator = model.listObjectsOfProperty(graphProperty);
        
        while(graphIterator.hasNext()){
        	String uri = graphIterator.next().toString();
        	graphList.add(uri);
        }
        
        
//        HashMap<String, Double> classMatchMeasureScore = new HashMap<String, Double>();
//        HashMap<String, Double> betweennessMeasureScore = new HashMap<String, Double>();
//        HashMap<String, Double> semanticSimilarityMeasureScore = new HashMap<String, Double>();
//        HashMap<String, Double>  densityMeasureScore =new HashMap<String, Double>();
                
        classMatchMeasureScore = cmm.getClassMatchMeasure(graphList, model, queryString); 
        betweennessMeasureScore = bm.getBetweennessMeasure(graphList, model);
        semanticSimilarityMeasureScore = ssm.getsemanticSimilarityMeasureScore(graphList, model);
        densityMeasureScore = dm.getDensityMeasure(graphList, model);
        
        
        this.getNormalizedValues(classMatchMeasureScore);
        this.getNormalizedValues(semanticSimilarityMeasureScore);
        this.getNormalizedValues(betweennessMeasureScore);
        this.getNormalizedValues(densityMeasureScore);
        
        for (int count=0; count<graphList.size() ; count++){ 
        	String graphIRI = graphList.get(count);
        	double cmm_score = 0.0;
        	if(classMatchMeasureScore.containsKey(graphIRI)) {
        		cmm_score = classMatchMeasureScore.get(graphIRI);
        		}
        	double bm_score = 0.0;
        	if(betweennessMeasureScore.containsKey(graphIRI)) {
        		bm_score = betweennessMeasureScore.get(graphIRI);
        	}
        	double ssm_score = 0.0;
        	if(semanticSimilarityMeasureScore.containsKey(graphIRI)) { 
        		ssm_score = semanticSimilarityMeasureScore.get(graphIRI);
        	} 
        	double dm_score = 0.0;
        	if(densityMeasureScore.containsKey(graphIRI)) {
        		dm_score = densityMeasureScore.get(graphIRI);
        	}
        	double score = (0.4 * cmm_score) + (0.3 * bm_score) + (0.2 * ssm_score) + (0.1 * dm_score);
        	System.out.println("cmm_score : " + cmm_score + "bm_score : "+ bm_score + "ssm_score : " + ssm_score+ "dm_score : " +dm_score);
        	System.out.println(" Graph : " +graphIRI+" score : "+score);
        	
        	totalScore.put(graphIRI, score);
        }
        
        
        
       // System.out.println("Graph List : " + graphList);
 
        /*********************** Calculate ssm Value for each graph ***********************************/
     //   HashMap<String, Double> betweennessMeasureScore = new HashMap<String, Double>();
     
        /*************************** Sort Hash map for bm25 score **********************************/
      
        HashMap<String, Double> sortedTotalScore = sortByValues(totalScore);
        
        /************************** put sorted values into  ArrayList *******************************/
        ArrayList<String> _temp = new ArrayList<String>();  
        for (Map.Entry<String, Double> entry : sortedTotalScore.entrySet()) {
        	
        	String graph = entry.getKey().toString(); 
        	
 //       	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graph));  	
//        	
//        	HashMap<String, Double> sorted = new HashMap<String, Double>();
//        	HashMap<String, Double> map = new HashMap<String, Double>();
//        	
//        	while(uriIterator.hasNext()){
//        		String term = uriIterator.next().toString();
//        		if(_temp.contains(term)) { }
//            	else {
//            	    _temp.add(term);
//            	    TF_IDFHolder holder = new TF_IDFHolder();
//            	    holder = getTF_IDFValues(term, graph);
//            	    double tfIdf = holder.getTF_IDF();
//            	    map.put(term, tfIdf);   
//            	    }     		
//        	}
//        	
//        	sorted = this.sortByValues(map);
//        	
//        	for (Map.Entry<String, Double> entry2 : sorted.entrySet()) { 
//        		ResultFormatter result = new ResultFormatter();
//        		String term = entry2.getKey();
//            	result.setTermIRI(term);
//            	result.setGraphIRI(graph);
//            	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
//            	result.setScore(entry.getValue().toString());
//            	resultList.add(result);
//            	System.out.println("" + term + "" + entry.getValue());
//        	}
//        	
//        }
        
        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(entry.getKey().toString()));
            HashMap<String, Double> resourceMap = new HashMap<String, Double>();   
            while(uriIterator.hasNext()){
            	ResultFormatter result = new ResultFormatter();
            	String term = uriIterator.next().toString();
               	if(_temp.contains(term)) { }
            	else {
            	    _temp.add(term);

            	    result.setTermIRI(term);
                	result.setGraphIRI(entry.getKey().toString());
                	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
                	result.setScore(entry.getValue().toString());
                	resultList.add(result);
                 // 	System.out.println(" Term " + term + " Score " + entry.getValue().toString() );
                  	System.out.println(term);
            	}
            	
            }
  
        } 
        return resultList;
 	}
 	

		
  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//System.out.println(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}

  	 
	  private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }

	  
	  public void getNormalizedValues(HashMap<String, Double> map){
		  System.out.println("Normalizing . . . ." );
		  double maxVal = 0.0;
		  for(Map.Entry<String, Double> entry: map.entrySet()){
			  
			  if (maxVal < entry.getValue()){
				  maxVal = entry.getValue();
			  }
		  }
		  System.out.println( "maxVal" + maxVal );
		  
		  for(Map.Entry<String, Double> entry: map.entrySet()){
			  String key = entry.getKey();
			  double value = entry.getValue();
			  value = value/maxVal;
			  System.out.println( "Normalized Value " + value );
			  map.put(key, value);
		  }
		  
	  }

	}
