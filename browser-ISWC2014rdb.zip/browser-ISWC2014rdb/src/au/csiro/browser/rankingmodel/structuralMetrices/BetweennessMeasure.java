package au.csiro.browser.rankingmodel.structuralMetrices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import jdbm.PrimaryTreeMap;
import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.rankingmodel.vectorspace.QueryVector;
import au.csiro.browser.store.QuadStore;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
public class BetweennessMeasure {

//	Model ontology = ModelFactory.createDefaultModel();
		Paths pathClass;
		private PrimaryTreeMap<String, HashMap<String, HashMap<String, ArrayList<String>>>> map;
		TfIdf_Data tfIdfClass= TfIdf_Data.getDefaultMap();
	  	private PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
	  	
		public BetweennessMeasure(){
			pathClass = Paths.getDefaultMap();
			map = pathClass.get_adjacency_matrix_map();
		}
		
	public ArrayList<ResultFormatter> getRankedClasses(Model model, ArrayList<String> queryString) {

		 ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
	       
		
	//	BetweenessMeasureCal btw = new BetweenessMeasureCal();
//		btw.calculatePaths();
   		List<String> graphList = new ArrayList<String>();
   	//	HashMap<String, Double> betweennessMeasure = new HashMap<String, Double>();
        
   		Property props = model.getProperty("http://www.biomeanalytics.com/model/orthoOntology.owl#hasProperty");
        Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
        Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
        /********************  Get All graphs in the Result Set *****************************/
        
        NodeIterator graphIterator = model.listObjectsOfProperty(graphProperty);
        
        while(graphIterator.hasNext()){
        	String uri = graphIterator.next().toString();
        	graphList.add(uri);
        }
        
       // System.out.println("Graph List : " + graphList);
 
        /*********************** Calculate ssm Value for each graph ***********************************/
        HashMap<String, Double> betweennessMeasureScore = new HashMap<String, Double>();
     //   DensityCalculator densityCal = new DensityCalculator();
      //  densityCal.saveDensityforCorpus();

        for (int count=0; count<graphList.size() ; count++){
        //for (int count=0; count<1 ; count++){	PrimaryTreeMap<String, HashMap<String, HashMap<String, ArrayList<String>>>> map = path.get_adjacency_matrix_map();
        	String graphIRI = graphList.get(count);
        	System.out.println(" graphIRI " + graphIRI);
        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graphIRI));
            double finalBetweennessValue = 0;
        	double totalBetweennessValue = 1;
            double resourceCount = 0;
            while(uriIterator.hasNext()){
            	resourceCount++;
            	String uri = uriIterator.next().toString();
            	double classBetweennessValue = 0;
            	
            	classBetweennessValue = this.findBetweennessCount(graphIRI, uri);
            	
            	System.out.println(" URI :" + uri + "classBetweennessValue : " +classBetweennessValue );
            	totalBetweennessValue = totalBetweennessValue + classBetweennessValue;
            }
            System.out.println(" totalBetweennessValue :" + totalBetweennessValue + "resourceCount : " +resourceCount );
            finalBetweennessValue = totalBetweennessValue/resourceCount;
            betweennessMeasureScore.put(graphIRI, finalBetweennessValue);
        }
        
        /*************************** Sort Hash map for bm25 score **********************************/
      
        HashMap<String, Double> sortedBetweennessValueScore = sortByValues(betweennessMeasureScore);
        
        /************************** put sorted values into  ArrayList *******************************/
        ArrayList<String> _temp = new ArrayList<String>();  
        for (Map.Entry<String, Double> entry : sortedBetweennessValueScore.entrySet()) {
        	
        	String graph = entry.getKey().toString(); 
        	
//        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graph));  	
//        	
//        	HashMap<String, Double> sorted = new HashMap<String, Double>();
//        	HashMap<String, Double> map = new HashMap<String, Double>();
//        	
//        	while(uriIterator.hasNext()){
//        		String term = uriIterator.next().toString();
//        		if(_temp.contains(term)) { }
//            	else {
//            	    _temp.add(term);
//            	    TF_IDFHolder holder = new TF_IDFHolder();
//            	    holder = getTF_IDFValues(term, graph);
//            	    double tfIdf = holder.getTF_IDF();
//            	    map.put(term, tfIdf);   
//            	    }     		
//        	}
//        	
//        	sorted = this.sortByValues(map);
//        	
//        	for (Map.Entry<String, Double> entry2 : sorted.entrySet()) { 
//        		ResultFormatter result = new ResultFormatter();
//        		String term = entry2.getKey();
//            	result.setTermIRI(term);
//            	result.setGraphIRI(graph);
//            	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
//            	result.setScore(entry.getValue().toString());
//            	resultList.add(result);
//            	System.out.println("" + term + "" + entry.getValue());
//        	}
//        	
//        }
        
        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(entry.getKey().toString()));
         //   HashMap<String, Double> resourceMap = new HashMap<String, Double>();   
            while(uriIterator.hasNext()){
            	ResultFormatter result = new ResultFormatter();
            	String term = uriIterator.next().toString();
               	if(_temp.contains(term)) { }
            	else {
            	    _temp.add(term);

            	    result.setTermIRI(term);
                	result.setGraphIRI(entry.getKey().toString());
                	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
                	result.setScore(entry.getValue().toString());
                	resultList.add(result);
                  	System.out.println(" Term " + term + " Score " + entry.getValue().toString() );
                 // 	System.out.println(term);
            	}
            	
            }
  
        } 
        return resultList;
 	}
 	
	private TF_IDFHolder getTF_IDFValues(String term, String graphIRI){
		//System.out.println("TERMS " + term +" GRAPHS " + graphIRI );
		TF_IDFHolder tf_IdfHolder = new TF_IDFHolder();
		
	  double tf = 0;
	  double idf = 0;
	  double tf_idf = 0;
	  
	  if (corpus_tfIdf_Map.containsKey(graphIRI)) {
			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(graphIRI);
			if(ontologyTfIDFs.containsKey(term)) {
				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(term);
		  		tf = tfIdfs.get(1);
				idf = tfIdfs.get(2);
				tf_idf = tfIdfs.get(3);
			}
		}
  
	  	tf_IdfHolder = new TF_IDFHolder(tf, idf, tf_idf);    
	  	return tf_IdfHolder;
	}
		
  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//System.out.println(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}

  	 
	  private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }

	 	public int findBetweennessCount(String graphIRI , String node){
	  		int count = 0;
	  		
	  		try {   	
			if(map.containsKey(graphIRI)){
				
				HashMap<String, HashMap<String, ArrayList<String>>> ontologyMap = new HashMap<String, HashMap<String, ArrayList<String>>>();
				ontologyMap = map.get(graphIRI);
				
				for (Map.Entry<String, HashMap<String, ArrayList<String>>> entry2: ontologyMap.entrySet()){
					String firstNode = entry2.getKey().toString();
					if (firstNode.equalsIgnoreCase(node))  {
						
					} else {
						HashMap<String, ArrayList<String>> classMap = new HashMap<String, ArrayList<String>>();
						classMap = entry2.getValue();
						for (Map.Entry<String, ArrayList<String>> entry3: classMap.entrySet()){
							String secondNode = entry3.getKey().toString();
							if (secondNode.equalsIgnoreCase(node))  { 
								
							} else {
								ArrayList<String> pathNodes = entry3.getValue();
								if (pathNodes.contains(node)){
									count++;
								}
							}
						}
					}
				}
			}
	  	}catch (Exception e) {
	  		
	  	} finally { 
	  	//	pathClass.closeConnection();
	  	}
	  		return count;
	  	}
	 	
	 	public HashMap<String, Double> getBetweennessMeasure(ArrayList<String> graphList, Model model){
	    HashMap<String, Double> betweennessMeasureScore = new HashMap<String, Double>();
	     //   DensityCalculator densityCal = new DensityCalculator();
	      //  densityCal.saveDensityforCorpus();
	    Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
	        for (int count=0; count<graphList.size() ; count++){
	        //for (int count=0; count<1 ; count++){	PrimaryTreeMap<String, HashMap<String, HashMap<String, ArrayList<String>>>> map = path.get_adjacency_matrix_map();
	        	String graphIRI = graphList.get(count);
	        	System.out.println(" graphIRI " + graphIRI);
	        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graphIRI));
	            double finalBetweennessValue = 0;
	        	double totalBetweennessValue = 1;
	            double resourceCount = 0;
	            while(uriIterator.hasNext()){
	            	resourceCount++;
	            	String uri = uriIterator.next().toString();
	            	double classBetweennessValue = 0;
	            	
	            	classBetweennessValue = this.findBetweennessCount(graphIRI, uri);
	            	
	            	System.out.println(" URI :" + uri + "classBetweennessValue : " +classBetweennessValue );
	            	totalBetweennessValue = totalBetweennessValue + classBetweennessValue;
	            }
	            System.out.println(" totalBetweennessValue :" + totalBetweennessValue + "resourceCount : " +resourceCount );
	            finalBetweennessValue = totalBetweennessValue/resourceCount;
	            betweennessMeasureScore.put(graphIRI, finalBetweennessValue);
	        }
	        return betweennessMeasureScore;
	 	}
	}
