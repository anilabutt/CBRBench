package au.csiro.browser.rankingmodel.structuralMetrices;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.logging.Logger;

import jdbm.PrimaryTreeMap;
import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;
import au.csiro.browser.store.QuadStore;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

public class BetweenessMeasureCal {

//	Model ontology = ModelFactory.createDefaultModel();
		public QuadStore store = QuadStore.getDefaultStore();
		public VirtGraph connection = store.getConnection();
		public Logger logger = Logger.getLogger(getClass().getName());
		
	public void calculatePaths() {

		Paths pathClass = Paths.getDefaultMap();
        /********************  Get All graphs in the Result Set *****************************/
		ArrayList<String> graphs = this.getExistingLoadedOntology();
       // for (int count=1; count<2 ; count++){
        for (int count=0; count<graphs.size() ; count++){
        //for (int count=0; count<1 ; count++){	
        	double ssmSumForAllConcepts = 0.0;
        	double k =0;
        	double SSM=0.0;
        	
        	//String graphIRI = graphList.get(count);
        	
        	String graphIRI = graphs.get(count);
        	logger.info(" /********** "+graphIRI +" *********/");
     
        	ArrayList<String> classList = this.getClassList(graphIRI);
        	
        	HashMap<String, HashMap<String, ArrayList<String>>> ontPaths = new HashMap<String, HashMap<String, ArrayList<String>>>();
        	
        //	for(int i=0; i<1 ; i++){
        		for(int i=0; i<classList.size()-1 ; i++){
            	
        		HashMap<String, ArrayList<String>> listOfPaths = new HashMap<String, ArrayList<String>>();
        		ArrayList<String> path =  new ArrayList<String>();
        		String concept1 = classList.get(i);
        		//concept1 = "http://art.uniroma2.it/ontologies/lime#BidirectionalBilingualDictionary";
            	//for (int j=i+1; j<2 ; j++) {
            		for (int j=i+1; j<classList.size() ; j++) {
            	
            		String concept2 = classList.get(j);
            		//concept2="http://art.uniroma2.it/ontologies/lime#SKOSDataset";
            	try{	
            		//logger.info(concept1 + "    " + concept2);
              		Tree tree1 = new Tree(concept1);
              		//System.out.println(" Tree root node is : " + tree1.getRoot().getNode());
              		Tree tree2 = new Tree(concept2);
            		//get ssm for a pair of resources
              		//System.out.println(" Tree root node is : " + tree1.getRoot().getNode());

            		String commonNode = getMinimumPathCommonNode(concept1, concept2, graphIRI, tree1,tree2);
            		
            		//System.out.println( " commonNode :  " + commonNode );
            		if (commonNode.equals("")){} else {
            		path = getPath(commonNode, tree1);
            		
            		Collections.reverse(path);
            		//System.out.println( " path1 :  " + path );
            		path.add(commonNode);
            		//System.out.println( " path :  " + path );
            		
            		ArrayList<String> path2 = getPath(commonNode, tree2);
            		//System.out.println( " path2 :  " + path2 );
            		
            		path.addAll(path2);}
            		
            		logger.info( " path :  " + path );
            		
            		
            	}catch(Exception e){
            		System.out.println(e +"  " + concept1 + "  " + concept2);
            		}

            		///Store it now
            		listOfPaths.put(concept2, path);
            	}
            	
            	ontPaths.put(concept1, listOfPaths);
            }
        	pathClass.save_adjacency_matrix_map(graphIRI, ontPaths);
        }
        pathClass.closeConnection();
       }
        
        /*************************** Sort Hash map for bm25 score **********************************/
      
       // HashMap<String, Double> sortedSemanticSimilarityMeasureScore = sortByValues(betweennessMeasure);
        
 
 	
 
	public static ArrayList<String> getPath(String nodeIRI, Tree tree){
		
		//System.out.println(" ******** Get Path For "+nodeIRI+"********* ");
		ArrayList<String> list = new ArrayList<String>();

		Node node = tree.getNode(nodeIRI, tree.getRoot());
		
		while(!( node.getNode().equalsIgnoreCase(tree.getRoot().getNode()))){

			//System.out.println(" ******** Compare "+node.getNode() +"********* ");
			node = node.getNodeParent();
			String parentIRI = node.getNode();
			list.add(parentIRI);
			
		}
		
		return list;
	} 
 		
  
  	public String getMinimumPathCommonNode(String concept1, String concept2, String graphIRI, Tree tree1, Tree tree2){
  		
  		double length = 1.0 ;



 		HashMap<String, Double> map = new HashMap<String, Double>();
//  		HashMap<String, Double> superClassMapForConcept2 = new HashMap<String, Double>();
//  		
//  		//add concepts to their respective maps
 		map.put(concept1, 0.0);
 		map.put(concept2, 0.0);
//  		superClassMapForConcept2.put(concept2, 0.0);
  	
  		//get superclass lists for both resources
  		ArrayList<String> currentSuperClassesForConcept1 = getSuperClassList(concept1, graphIRI);
        ArrayList<String> currentSuperClassesForConcept2 = getSuperClassList(concept2, graphIRI);
  		
        //add these lists to their respective maps along with their path length
  		
        tree1.addChildren(currentSuperClassesForConcept1);
        tree2.addChildren(currentSuperClassesForConcept2);
        copyMap(map, currentSuperClassesForConcept1, length);
        copyMap(map, currentSuperClassesForConcept2, length);
    		
//  		ArrayList<String> currentSuperClassesForConcept1 = new ArrayList<String>();
//  		currentSuperClassesForConcept1.addAll(list_1);
//  		
//  		ArrayList<String> currentSuperClassesForConcept2 = new ArrayList<String>();
//  		currentSuperClassesForConcept1.addAll(list_2);
  		
  		String matchedNode = intersection(tree1, tree2, map);
  		
  		while (matchedNode.equalsIgnoreCase("")){ 			
  			
  			if(length<20) {
  	  			length++;
  				ArrayList<String> list1 = new ArrayList<String>();
  				list1.addAll(currentSuperClassesForConcept1);
  			
  				ArrayList<String> list2 = new ArrayList<String>();
  				list2.addAll(currentSuperClassesForConcept2);
  			
  				currentSuperClassesForConcept1.clear();
  				currentSuperClassesForConcept2.clear();
  			
  				currentSuperClassesForConcept1 = getSuperClassListForList(list1, graphIRI, tree1);
  				currentSuperClassesForConcept2 = getSuperClassListForList(list2, graphIRI, tree2);
  			
  				if(currentSuperClassesForConcept1.isEmpty() && currentSuperClassesForConcept2.isEmpty()){
  					length = 100;
  					
  					break;
  				} else {
  					copyMap(map, currentSuperClassesForConcept1, length);
  					copyMap(map, currentSuperClassesForConcept2, length);
  					matchedNode = intersection(tree1, tree2, map);	
  				}
	
  			} else { matchedNode = "notFound";}		
  		}
  			
  		return matchedNode;
  	}
  	

  	 public String intersection(Tree tree1, Tree tree2, HashMap<String, Double> map){
  		String matchedNode = "";
  		
  		for(Map.Entry<String, Double> entry: map.entrySet()){
  			String nodeIRI = entry.getKey();
  			if( (tree1.contains(nodeIRI, tree1.getRoot())) && (tree2.contains(nodeIRI, tree2.getRoot())) ){
  				matchedNode = nodeIRI;
  				break;
  			}
  		}
  		
  		return matchedNode;
  	}
  	
  	public ArrayList<String> getSuperClassListForList(ArrayList<String> list, String graphIRI, Tree tree){

  		ArrayList<String> superClassList = new ArrayList<String>();
  		
  		for (int i=0; i<list.size() ; i++){
  			String nodeIRI = list.get(i);
  			Node node = tree.getNode(nodeIRI, tree.getRoot());	
  			
  			ArrayList<String> newList = new ArrayList<String>();
  			
  			newList = getSuperClassList(nodeIRI, graphIRI);
  			
  			for(int j=0; j<newList.size(); j++){
  				superClassList.add(newList.get(j));

  			}
				tree.addChildrenForNode(node,newList);
  		}
  		
  		//System.out.println(superClassList);
  		return superClassList;
  	}

 	public ArrayList<String> getClassList(String graphIRI){
  		//int length = 0 ;
  		
  		ArrayList<String> superClassList = new ArrayList<String>();
  		
  		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
	            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
	            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
  						"SELECT ?class"
						+ " FROM <"+graphIRI+"> "
						+ " WHERE { {?class rdf:type rdfs:Class} UNION {?class rdf:type owl:Class.} "
								+ " FILTER (!(isBlank(?class)) && (?class != owl:Thing))}";
		
  		//System.out.println(sparql);
		
		try {

			VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);

			ResultSet results = vqe.execSelect();
			while (results.hasNext()) {
				QuerySolution result = results.nextSolution();
			    String graph = result.get("class").toString();
			    superClassList.add(graph);
	    	  }
		} catch(Exception e){
			System.out.println(e);
		}
		System.out.println(superClassList);
  		return superClassList;
  	}
 	
 	
  	public ArrayList<String> getSuperClassList(String concept, String graphIRI){
  		//int length = 0 ;
  		
  		ArrayList<String> superClassList = new ArrayList<String>();
  		
  	//	System.out.println("**************** SuperClass for concept " + concept + " **************** ");
  		
  		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
	            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
	            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
  						"SELECT  DISTINCT ?object"
						+ " FROM <"+graphIRI+"> "
						+ " WHERE {<"+concept+"> rdfs:subClassOf ?object."
								+ "{?object rdf:type rdfs:Class} UNION {?object rdf:type owl:Class.}"
								+ "FILTER (!(isBlank(?object)))}";
  		try {

			VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);

			ResultSet results = vqe.execSelect();
			while (results.hasNext()) {
				QuerySolution result = results.nextSolution();
			    String graph = result.get("object").toString();
			    superClassList.add(graph);
	    	  }
		} catch(Exception e){
			System.out.println(e);
		}
		System.out.println(superClassList);
  		return superClassList;
  		
//		String query = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"
//  				+ " SELECT DISTINCT ?superClasses WHERE {<"+concept+"> rdfs:subClassOf ?superClasses}";
//  		System.out.println(query);
//  		try {
//	 		  QueryExecution exec = QueryExecutionFactory.create(query, graphIRI);
//	    	  ResultSet resultset = exec.execSelect();	  
//	    	  while (resultset.hasNext()){
//	    		  QuerySolution qs = resultset.nextSolution();
//	    		  String superClass = qs.getResource("superClasses").toString();
//	    		  System.out.println(superClass);
//	    		  superClassList.add(superClass);
//	    	  }
//		 }catch(Exception e){
//			// System.out.println(query);
//			 System.out.println(e);
//		 }		
  		
  		//return superClassList;
  	}
  
//  	public Model getOntologyGraph(String ontologyIRI){
//  		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
//  				"CONSTRUCT {?subject rdfs:subClassOf ?object} FROM <"+ontologyIRI+"> WHERE {?subject rdfs:subClassOf ?object}";
//  		System.out.println(sparql);
//  		QuadStore store = QuadStore.getDefaultStore();
//		Model model = store.execConstruct(sparql, false);
//		//model.toString();
//  		return model;
//  	}
  	

  	 
  	 public HashMap<String, Double> copyMap(HashMap<String, Double> map, ArrayList<String> list, double length) {
  		//HashMap<String, Double> map = new HashMap<String, Double>();
       
  		 for(int i=0; i<list.size();i++){
  			 if (map.containsKey(list.get(i))){	 
  			 } else {
  				 map.put(list.get(i), length);}
  		 }
        return map;
     }
  	 
	  private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
	  
      public boolean equals(Node node1, Node node2){
      	boolean flag=false;
      	if(node1.getNode().equalsIgnoreCase(node2.getNode())){
      		flag=true;
      	} else {}
      	
      	return flag;
      }
  	public ArrayList<String> getExistingLoadedOntology(){

		ArrayList<String> list = new ArrayList<String>();
		 
		String sparql = "SELECT DISTINCT ?graph "
				+ " WHERE {GRAPH ?graph {?subject ?property ?object}} ORDER BY (?graph)";
		 
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);

			ResultSet results = vqe.execSelect();
			while (results.hasNext()) {
				QuerySolution result = results.nextSolution();
			    String graph = result.get("graph").toString();
			    
			    System.out.println(graph);
			    list.add(graph);
			}     
		    
			return list;	         
	 }
  	
}
