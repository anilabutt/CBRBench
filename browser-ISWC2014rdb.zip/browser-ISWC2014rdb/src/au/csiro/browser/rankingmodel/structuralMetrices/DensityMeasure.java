package au.csiro.browser.rankingmodel.structuralMetrices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import jdbm.PrimaryTreeMap;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;

public class DensityMeasure {

	DensityMap density = new DensityMap();
	TfIdf_Data tfIdfClass= TfIdf_Data.getDefaultMap();
  	private PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
    PrimaryTreeMap<String, HashMap<String, HashMap<String, Integer>>> graphDensityMap = density.get_density_map();
    
	public ArrayList<ResultFormatter> getRankedClasses(Model model, ArrayList<String> queryString) {
 		
        ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
   		List<String> graphList = new ArrayList<String>();
   		HashMap<String, Double> densityMeasureScore = new HashMap<String, Double>();
//        
  		DensityCalculator densityCal = new DensityCalculator();
//	 	densityCal.saveDensityforCorpus();

        Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
        Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
        /********************  Get All graphs in the Result Set *****************************/
        
        NodeIterator graphIterator = model.listObjectsOfProperty(graphProperty);
        
        while(graphIterator.hasNext()){
        	String uri = graphIterator.next().toString();
        	graphList.add(uri);
        }
        
       // System.out.println("Graph List : " + graphList);
 
        /*********************** Calculate BM25 Value for each graph ***********************************/

        PrimaryTreeMap<String, HashMap<String, HashMap<String, Integer>>> graphDensityMap = density.get_density_map();
    	
        for (int i=0; i<graphList.size() ; i++){
        	
        	String graphIRI = graphList.get(i);
        	
        //	System.out.println(" /********** "+graphIRI +" *********/");
        	
        	double ontologyDensity =0.0;
        	int matchedClassesCount=0;
        	
        	if (graphDensityMap.containsKey(graphIRI)) {

        		
        		HashMap<String, HashMap<String, Integer>> ontologyDensityMap = graphDensityMap.get(graphIRI);
    			//System.out.println(ontologyDensityMap);
        		//System.out.println(" ontologyDensityMap " +  ontologyDensityMap);
        		ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graphIRI));
            
        		while(uriIterator.hasNext()){
        			matchedClassesCount++;
        			String uri = uriIterator.nextResource().toString();
        			//System.out.println(uri);
        			HashMap<String,Integer> classDensityMap = new HashMap<String,Integer>();

        			double subClass= 0 , superClass = 0, relation =0, sibling=0;
        			if(ontologyDensityMap.containsKey(uri)) {
        					classDensityMap = ontologyDensityMap.get(uri);
        					subClass= classDensityMap.get("subClasses");
            				superClass = classDensityMap.get("superClasses");
            				relation = classDensityMap.get("relations");
            				sibling = classDensityMap.get("siblings");
            			//	System.out.println(classDensityMap);
        				}
            	
        			//	System.out.println("subClass : " + subClass + " superClass : " + superClass + "relation : " + relation+ " sibling : " + sibling);
        				double classDensity = (1 * subClass) + (0.25 * superClass) +(0.5 * relation)+(0.5 * sibling);
        				ontologyDensity = ontologyDensity + classDensity;
        			}
        			//System.out.println("ontologyDensity : " + ontologyDensity + "matchedClassesCount : " + matchedClassesCount);
        			ontologyDensity = ontologyDensity/matchedClassesCount;
        		}
        		densityMeasureScore.put(graphIRI, ontologyDensity);	
        	}
                
        /*************************** Sort Hash map for bm25 score **********************************/
      
        HashMap<String, Double> sortedClassMatchScoreMap = sortByValues(densityMeasureScore);
        
        /************************** put sorted values into  ArrayList *******************************/
        ArrayList<String> _temp = new ArrayList<String>();  
       
        for (Map.Entry<String, Double> entry : sortedClassMatchScoreMap.entrySet()) {
        	
        	
	String graph = entry.getKey().toString(); 
        	
//        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graph));  	
        	
//        	HashMap<String, Double> sorted = new HashMap<String, Double>();
//        	HashMap<String, Double> map = new HashMap<String, Double>();
//        	
//        	while(uriIterator.hasNext()){
//        		String term = uriIterator.next().toString();
//        		if(_temp.contains(term)) { }
//            	else {
//            	    _temp.add(term);
//            	    TF_IDFHolder holder = new TF_IDFHolder();
//            	    holder = getTF_IDFValues(term, graph);
//            	    double tfIdf = holder.getTF_IDF();
//            	    map.put(term, tfIdf);   
//            	    }     		
//        	}
//        	
//        	sorted = this.sortByValues(map);
//        	
//        	for (Map.Entry<String, Double> entry2 : sorted.entrySet()) { 
//        		ResultFormatter result = new ResultFormatter();
//        		String term = entry2.getKey();
//            	result.setTermIRI(term);
//            	result.setGraphIRI(graph);
//            	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
//            	result.setScore(entry.getValue().toString());
//            	resultList.add(result);
//            	System.out.println("" + term + "" + entry.getValue());
//        	}
//        	
//        }
        	
        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(entry.getKey().toString()));
            HashMap<String, Double> resourceMap = new HashMap<String, Double>();   
            while(uriIterator.hasNext()){
               	ResultFormatter result = new ResultFormatter();
            	String term = uriIterator.next().toString();
               	if(_temp.contains(term)) { }
            	else {
            	    _temp.add(term);

                	result.setTermIRI(term);
                	result.setGraphIRI(entry.getKey().toString());
                	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
                	result.setScore(entry.getValue().toString());
                	resultList.add(result);
                	System.out.println("" + term + "" + entry.getValue());
                	//	System.out.println(term);
            	}
            	
            }
                   
        }
//           	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(entry.getKey().toString()));

//            while(uriIterator.hasNext()){
//            	
//            	ResultFormatter result = new ResultFormatter();
//            	String term = uriIterator.next().toString();
//            	if(_temp.contains(term)) { }
//            	else {
//            	    _temp.add(term);
//            	    result.setTermIRI(term);
//            	    result.setGraphIRI(entry.getKey().toString());
//            	    result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
//            	    result.setScore(entry.getValue().toString());
//            	    resultList.add(result);
//            	    System.out.println(" Term " + term + " Score " + entry.getValue().toString() );
//            	}
//            }
//        }
        
        return resultList;
 	}
 	
 
private TF_IDFHolder getTF_IDFValues(String term, String graphIRI){
		//System.out.println("TERMS " + term +" GRAPHS " + graphIRI );
		TF_IDFHolder tf_IdfHolder = new TF_IDFHolder();
		
		  double tf = 0;
	  double idf = 0;
	  double tf_idf = 0;
	  
	  if (corpus_tfIdf_Map.containsKey(graphIRI)) {
			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(graphIRI);
			if(ontologyTfIDFs.containsKey(term)) {
				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(term);
		  		tf = tfIdfs.get(1);
				idf = tfIdfs.get(2);
				tf_idf = tfIdfs.get(3);
			}
		}
  
	  	tf_IdfHolder = new TF_IDFHolder(tf, idf, tf_idf);    
	  	return tf_IdfHolder;
	}
	
  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//System.out.println(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}
	
  	
	  private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
	  
	 	public HashMap<String, Double> getDensityMeasure(ArrayList<String> graphList, Model model){
	 		double ontologyDensity =0.0;
        	int matchedClassesCount=0;
		    HashMap<String, Double> densityMeasureScore = new HashMap<String, Double>();
		     //   DensityCalculator densityCal = new DensityCalculator();
		      //  densityCal.saveDensityforCorpus();
		    Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");

	    	
	        for (int i=0; i<graphList.size() ; i++){
	        	
	        	String graphIRI = graphList.get(i);
	        	
	        	if (graphDensityMap.containsKey(graphIRI)) {

	        		HashMap<String, HashMap<String, Integer>> ontologyDensityMap = graphDensityMap.get(graphIRI);
	    			//System.out.println(ontologyDensityMap);
	        		//System.out.println(" ontologyDensityMap " +  ontologyDensityMap);
	        		ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graphIRI));
	            
	        		while(uriIterator.hasNext()){
	        			matchedClassesCount++;
	        			String uri = uriIterator.nextResource().toString();
	        			//System.out.println(uri);
	        			HashMap<String,Integer> classDensityMap = new HashMap<String,Integer>();

	        			double subClass= 0 , superClass = 0, relation =0, sibling=0;
	        			if(ontologyDensityMap.containsKey(uri)) {
	        					classDensityMap = ontologyDensityMap.get(uri);
	        					if (classDensityMap.containsKey("subClasses")){
	        					subClass= classDensityMap.get("subClasses");}
	        					if (classDensityMap.containsKey("superClasses")){
	            				superClass = classDensityMap.get("superClasses");}
	        					if (classDensityMap.containsKey("relations")){
	        						relation = classDensityMap.get("relations");
	        					}if (classDensityMap.containsKey("siblings")){
	            				sibling = classDensityMap.get("siblings"); 
	        					}
	            			//	System.out.println(classDensityMap);
	        				}
	            	
	        			//	System.out.println("subClass : " + subClass + " superClass : " + superClass + "relation : " + relation+ " sibling : " + sibling);
	        				double classDensity = (1 * subClass) + (0.25 * superClass) +(0.5 * relation)+(0.5 * sibling);
	        				ontologyDensity = ontologyDensity + classDensity;
	        			}
	        			//System.out.println("ontologyDensity : " + ontologyDensity + "matchedClassesCount : " + matchedClassesCount);
	        			ontologyDensity = ontologyDensity/matchedClassesCount;
	        		}
	        		densityMeasureScore.put(graphIRI, ontologyDensity);	
	        	}
		    
		        return densityMeasureScore;
		 	}
	
}
