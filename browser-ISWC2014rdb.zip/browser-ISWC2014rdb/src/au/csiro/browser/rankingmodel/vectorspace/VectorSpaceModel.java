package au.csiro.browser.rankingmodel.vectorspace;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.logging.Logger;

import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import au.csiro.browser.query.ResultFormatter;
import au.csiro.browser.query.TF_IDFHolder;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;

import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;

public class VectorSpaceModel {
	
	Logger logger = Logger.getLogger(getClass().getName());
	TfIdf_Data tfIdfClass= TfIdf_Data.getDefaultMap();
  	private PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();	
  	
 	public ArrayList<ResultFormatter> getRankedClasses(Model model, ArrayList<String> queryString) {

        ArrayList<ResultFormatter> resultList = new ArrayList<ResultFormatter>();
        
// 		DocNormCalculator docNormCal = new DocNormCalculator();
//	 	docNormCal.saveDocNormforCorpus();
	 	
		QueryVector queryVector = new QueryVector();
		HashMap<String, Double> queryMap = queryVector.getQueryVector(queryString);
		double query_norm = queryVector.getQueryNorm(queryMap);	
	    
 		ArrayList<ResultFormatter> rf = new ArrayList<ResultFormatter>();
   		List<String> graphList = new ArrayList<String>();
   		HashMap<String, Double> VectorSpaceScores = new HashMap<String, Double>();
        
        Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
        Property graphProperty = model.getProperty("http://www.w3.org/2000/01/rdf-schema#graph");
        
        /********************  Get All graphs in the Result Set *****************************/
        
        NodeIterator graphIterator = model.listObjectsOfProperty(graphProperty);
        
        while(graphIterator.hasNext()){
        	String uri = graphIterator.next().toString();
        	graphList.add(uri);
        }
        
       // logger.info("Graph List : " + graphList);
 
        /*********************** Calculate BM25 Value for each graph ***********************************/
         //   doc_norm = docNormCal.getDocNormValue("http://www.agfa.com/w3c/2009/malignantNeoplasm#") ;
     //   docNormCal.saveDocNormforCorpus();
        
        for (int i=0; i<graphList.size() ; i++){
    	    double doc_norm = 0.0;
        	String graphIRI = graphList.get(i);
        	
        	logger.info(" /********** "+graphIRI +" *********/");
        	
        	DocNormCalculator docNormCal = new DocNormCalculator();
        	doc_norm = docNormCal.getDocNormValue(graphIRI.toString());
      	
        	logger.info(doc_norm+"");

        	double TF_Value = 0.0;
        	double IDF_Value =0.0;
        	double TFIDF_Value =0.0;
        	
        	double score = 0.0;
        	double finalScore = 0; 
        	
        	for(Map.Entry<String, Double> entry: queryMap.entrySet()){
        		
        		String term = entry.getKey();
        		double queryTermTFIDF = entry.getValue();
        		double cumTF_IDF = 0.0;
        		
        		ArrayList<String> uriList = getURIsOfTerm(term,model);
        		
        		for(int j=0; j<uriList.size() ; j++){
        			
        			String uri = uriList.get(j);
                 	
        			TF_IDFHolder tf_IdfHolder = getTF_IDFValues(uri, graphIRI);
                 	TF_Value = tf_IdfHolder.getTF();
                 	IDF_Value = tf_IdfHolder.getIDF();
                 	TFIDF_Value = IDF_Value * TF_Value;
                 	
                 	cumTF_IDF = cumTF_IDF + TFIDF_Value;
                 }       
        		 
        		double DOC_TFIDF_FOR_TERM =  cumTF_IDF * queryTermTFIDF;
        		score = score + DOC_TFIDF_FOR_TERM;
        	}
          
        	if (doc_norm != 0) {
        		finalScore = score /(doc_norm * query_norm ); 
        	}
            
            VectorSpaceScores.put(graphIRI, finalScore);       	
        }
        
        /*************************** Sort Hash map for bm25 score **********************************/
      
        HashMap<String, Double> sortedBM25Map = sortByValues(VectorSpaceScores);
        
        /************************** put sorted values into  ArrayList *******************************/

        for (Map.Entry entry : sortedBM25Map.entrySet()) {
        	
        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(entry.getKey().toString()));
            HashMap<String, Double> resourceMap = new HashMap<String, Double>();   
//            while(uriIterator.hasNext()){
            	 while(uriIterator.hasNext()){
     	          	
                 	ResultFormatter result = new ResultFormatter();
                 	String term = uriIterator.next().toString();
                 	result.setTermIRI(term);
                 	result.setGraphIRI(entry.getKey().toString());
                 	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
                 	result.setScore(entry.getValue().toString());
                 	resultList.add(result);
                   	System.out.println("" + term + "" + entry.getValue());
                 	
                 }
        }
//        	String graph = entry.getKey().toString(); 
//        	
//        	ResIterator uriIterator = model.listSubjectsWithProperty(graphProperty, model.createResource(graph));  	
//        	
//        	HashMap<String, Double> sorted = new HashMap<String, Double>();
//        	HashMap<String, Double> map = new HashMap<String, Double>();
//        	
//        	while(uriIterator.hasNext()){
//        		String term = uriIterator.next().toString();
//        		TF_IDFHolder holder = new TF_IDFHolder();
//				holder = getTF_IDFValues(term, graph);
//				double tfIdf = holder.getTF_IDF();
//				map.put(term, tfIdf);        		
//        	}
//        	
//        	sorted = this.sortByValues(map);
//        	
//        	for (Map.Entry<String, Double> entry2 : sorted.entrySet()) { 
//        		ResultFormatter result = new ResultFormatter();
//        		String term = entry2.getKey();
//            	result.setTermIRI(term);
//            	result.setGraphIRI(graph);
//            	result.setTermLabel(getLabel(model.listObjectsOfProperty(model.createResource(term), label), term));
//            	result.setScore(entry.getValue().toString());
//            	resultList.add(result);
//            	System.out.println("" + term + "" + entry.getValue());
//        	}
//        	
//        }
        return resultList;
 	}
 	
 	public ArrayList<String> getURIsOfTerm(String term, Model model){
 		ArrayList<String> results = new ArrayList<String>();
 	
 		String sparql="PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> "
 				+ "SELECT ?uri "
 				+ " WHERE { "
 				+ " ?uri rdfs:label ?label."
 				+ " FILTER regex(?label, \""+ term +"\", \"i\")}";
 		
 		System.out.println(sparql);
 		Query query = QueryFactory.create(sparql);
 		
 		QueryExecution exec = QueryExecutionFactory.create(query, model);
 		 try {
	    	  ResultSet resultset = exec.execSelect();	  
	    	  while (resultset.hasNext()){
	    		  QuerySolution qs = resultset.nextSolution();
	    		  results.add(qs.get("uri").toString());   		  
	    	  }
 		 }catch(Exception e){
 			 logger.info(e+"");
 		 } finally {
 			 exec.close();
 		 }		
 		return results;
 	}
 	
 	private TF_IDFHolder getTF_IDFValues(String term, String graphIRI){
 		//System.out.println("TERMS " + term +" GRAPHS " + graphIRI );
 		TF_IDFHolder tf_IdfHolder = new TF_IDFHolder();
 		
 		  double tf = 0;
		  double idf = 0;
		  double tf_idf = 0;
		  
		  if (corpus_tfIdf_Map.containsKey(graphIRI)) {
    			HashMap<String, HashMap<Integer,Double>> ontologyTfIDFs = corpus_tfIdf_Map.get(graphIRI);
    			if(ontologyTfIDFs.containsKey(term)) {
    				HashMap<Integer,Double> tfIdfs = ontologyTfIDFs.get(term);
    		  		tf = tfIdfs.get(1);
    				idf = tfIdfs.get(2);
    				tf_idf = tfIdfs.get(3);
    			}
    		}
	  
		  	tf_IdfHolder = new TF_IDFHolder(tf, idf, tf_idf);    
		  	return tf_IdfHolder;
 	}
 	
  	private String getLabel(NodeIterator labelIterator, String propertyURI){   	
    	
  		String propLabel="";
    	
    	if (labelIterator.hasNext()){
    	RDFNode pLabel = labelIterator.nextNode();
    	propLabel = pLabel.toString();
    	//logger.info(propLabel + "is property Label");
    		if(propLabel.contains("@")) {
    			propLabel=propLabel.split("@")[0];
    		} 
    		if (propLabel.contains("^")){
    			propLabel= propLabel.split("\\^")[0];
    		}
    	} else {
    		propLabel = propertyURI;
    	}
    	return propLabel;
  	}
	
  	
	  private HashMap<String, Double> sortByValues(HashMap<String, Double> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Double> sortedHashMap = new LinkedHashMap<String, Double>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Double.parseDouble(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
	  
		public double getDocNormValue(String docId){
			double doc_norm = 0.0;
			PrimaryTreeMap<String, Double> doc_norm_map;
			RecordManager recMan;

			//		au.csiro.browser.rankingmodel.vectorspace.DocumentNormMap diskmap = new au.csiro.browser.rankingmodel.vectorspace.DocumentNormMap();
//			PrimaryTreeMap<String,Double> map = diskmap.get_doc_norm_map();
			String fileName = "doc_norm";
			try {
				recMan = RecordManagerFactory.createRecordManager(fileName);
				String recordName = "doc_norm_map";
				doc_norm_map = recMan.treeMap(recordName);
				doc_norm= doc_norm_map.get(docId);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.info("Can not get map becasue :" + e);
				//e.printStackTrace();
			} 

			return doc_norm;
		}
	
}
