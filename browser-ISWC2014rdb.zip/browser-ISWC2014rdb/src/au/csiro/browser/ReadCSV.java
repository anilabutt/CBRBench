package au.csiro.browser;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import jdbm.PrimaryTreeMap;
import au.csiro.browser.userstudy.PersonMap;

public class ReadCSV {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// event not in old = [http://www.semanticdesktop.org/ontologies/2007/04/02/ncal#UnionOfTimezoneObservanceEventFreebusyJournalTimezoneTodo, http://www.semanticdesktop.org/ontologies/2007/04/02/ncal#UnionOfTimezoneObservanceEventFreebusyTimezoneTodo, http://www.semanticdesktop.org/ontologies/2007/04/02/ncal#UnionOfAlarmEventFreebusyJournalTodo, http://purl.org/ontology/af/Loudness, http://www.freeclass.eu/freeclass_v1#C_A1992-gen, http://www.freeclass.eu/freeclass_v1#C_A2528-tax, http://www.freeclass.eu/freeclass_v1#C_A2528-gen, http://www.freeclass.eu/freeclass_v1#C_A2237-gen, http://www.freeclass.eu/freeclass_v1#C_A2239-gen, http://www.freeclass.eu/freeclass_v1#C_A1992-gen, http://www.freeclass.eu/freeclass_v1#C_A2528-tax, http://www.freeclass.eu/freeclass_v1#C_A2528-gen, http://www.freeclass.eu/freeclass_v1#C_A2237-gen, http://www.freeclass.eu/freeclass_v1#C_A2239-gen]
		// event not in new = [http://www.semanticdesktop.org/ontologies/2007/04/02/ncal#UnionOfEventFreebusy, http://www.semanticdesktop.org/ontologies/2007/04/02/ncal#EventStatus, http://www.semanticdesktop.org/ontologies/2007/04/02/ncal#UnionOfAlarmEventTodo, http://purl.org/ontology/af/Ornament, http://www.freeclass.eu/freeclass_v1#C_A2530-tax, http://www.freeclass.eu/freeclass_v1#C_A2524-gen, http://www.freeclass.eu/freeclass_v1#C_A2530-gen, http://www.freeclass.eu/freeclass_v1#C_A2232-gen, http://www.freeclass.eu/freeclass_v1#C_A2525-tax, http://www.freeclass.eu/freeclass_v1#C_A2530-tax, http://www.freeclass.eu/freeclass_v1#C_A2524-gen, http://www.freeclass.eu/freeclass_v1#C_A2530-gen, http://www.freeclass.eu/freeclass_v1#C_A2232-gen, http://www.freeclass.eu/freeclass_v1#C_A2525-tax]

		//location !old = [http://purl.obolibrary.org/obo/IEV_0000009, http://purl.obolibrary.org/obo/IEV_0001167, http://purl.obolibrary.org/obo/IEV_0000186, http://purl.obolibrary.org/obo/IEV_0000984, http://purl.obolibrary.org/obo/IEV_0001942, http://purl.obolibrary.org/obo/IEV_0000412, http://purl.obolibrary.org/obo/IEV_0001943, http://purl.obolibrary.org/obo/IEV_0000444, http://purl.obolibrary.org/obo/IEV_0000958, http://purl.obolibrary.org/obo/IEV_0000428, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_12652, http://purl.obolibrary.org/obo/HP_0000357, http://purl.obolibrary.org/obo/HP_0003042, http://purl.obolibrary.org/obo/HP_0004307, http://purl.obolibrary.org/obo/HP_0004976, http://purl.obolibrary.org/obo/HP_0002827, http://purl.obolibrary.org/obo/HP_0003834, http://purl.obolibrary.org/obo/HP_0002999, http://purl.obolibrary.org/obo/HP_0008826, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_12652]
		//location !new = [http://purl.obolibrary.org/obo/IEV_0001250, http://purl.obolibrary.org/obo/IEV_0003716, http://purl.obolibrary.org/obo/IEV_0003887, http://purl.obolibrary.org/obo/IEV_0000507, http://purl.obolibrary.org/obo/IEV_0000962, http://purl.obolibrary.org/obo/IEV_0000187, http://purl.obolibrary.org/obo/IEV_0000169, http://purl.obolibrary.org/obo/IEV_0001944, http://purl.obolibrary.org/obo/IEV_0000417, http://purl.obolibrary.org/obo/IEV_0001202, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_13132, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_14279, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2250, http://purl.obolibrary.org/obo/HP_0001374, http://purl.obolibrary.org/obo/HP_0005084, http://purl.obolibrary.org/obo/HP_0005050, http://purl.obolibrary.org/obo/HP_0005008, http://purl.obolibrary.org/obo/HP_0008141, http://purl.obolibrary.org/obo/HP_0005070, http://purl.obolibrary.org/obo/HP_0012095, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_13132, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_14279, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2250]

		//name !old = [http://d-nb.info/standards/elementset/gnd#PseudonymNameOfThePerson, http://d-nb.info/standards/elementset/gnd#RealNameOfThePerson, http://purl.obolibrary.org/obo/EMAP_34263, http://purl.obolibrary.org/obo/EMAP_10845, http://purl.obolibrary.org/obo/EMAP_6610, http://purl.obolibrary.org/obo/EMAP_34415, http://purl.obolibrary.org/obo/EMAP_34414, http://purl.obolibrary.org/obo/EMAP_34413, http://purl.obolibrary.org/obo/EMAP_34267, http://purl.obolibrary.org/obo/EMAP_34529, http://purl.obolibrary.org/obo/EMAP_34263, http://purl.obolibrary.org/obo/EMAP_10845, http://purl.obolibrary.org/obo/EMAP_6610, http://purl.obolibrary.org/obo/EMAP_34415, http://purl.obolibrary.org/obo/EMAP_34414, http://purl.obolibrary.org/obo/EMAP_34413, http://purl.obolibrary.org/obo/EMAP_34267, http://purl.obolibrary.org/obo/EMAP_34529]
		// name ! new = [http://d-nb.info/standards/elementset/gnd#PreferredNameOfThePerson, http://d-nb.info/standards/elementset/gnd#NameOfSmallGeographicUnitLyingWithinAnotherGeographicUnit, http://d-nb.info/standards/elementset/gnd#FullerFormOfNameOfThePerson, http://purl.obolibrary.org/obo/EMAP_34266, http://purl.obolibrary.org/obo/EMAP_34390, http://purl.obolibrary.org/obo/EMAP_34493, http://purl.obolibrary.org/obo/EMAP_34491, http://purl.obolibrary.org/obo/EMAP_10839, http://purl.obolibrary.org/obo/EMAP_34266, http://purl.obolibrary.org/obo/EMAP_34390, http://purl.obolibrary.org/obo/EMAP_34493, http://purl.obolibrary.org/obo/EMAP_34491, http://purl.obolibrary.org/obo/EMAP_10839]

		//organization !old =[http://purl.obolibrary.org/obo/OMRSE_00000015, http://purl.obolibrary.org/obo/GO_0043062, http://purl.obolibrary.org/obo/GO_0016050, http://purl.obolibrary.org/obo/ZP_0003403, http://purl.obolibrary.org/obo/ZP_0008025, http://purl.obolibrary.org/obo/ZP_0002261, http://purl.obolibrary.org/obo/ZP_0000486, http://purl.obolibrary.org/obo/ZP_0006715, http://purl.obolibrary.org/obo/ZP_0004652, http://purl.obolibrary.org/obo/ZP_0005938, http://purl.obolibrary.org/obo/ZP_0005002, http://purl.obolibrary.org/obo/ZP_0003810, http://purl.obolibrary.org/obo/ZP_0003403, http://purl.obolibrary.org/obo/ZP_0008025, http://purl.obolibrary.org/obo/ZP_0002261, http://purl.obolibrary.org/obo/ZP_0000486, http://purl.obolibrary.org/obo/ZP_0006715, http://purl.obolibrary.org/obo/ZP_0004652, http://purl.obolibrary.org/obo/ZP_0005938, http://purl.obolibrary.org/obo/ZP_0005002, http://purl.obolibrary.org/obo/ZP_0003810, http://purl.obolibrary.org/obo/ZP_0003403, http://purl.obolibrary.org/obo/ZP_0008025, http://purl.obolibrary.org/obo/ZP_0002261, http://purl.obolibrary.org/obo/ZP_0000486, http://purl.obolibrary.org/obo/ZP_0006715, http://purl.obolibrary.org/obo/ZP_0004652, http://purl.obolibrary.org/obo/ZP_0005938, http://purl.obolibrary.org/obo/ZP_0005002, http://purl.obolibrary.org/obo/ZP_0003810]
		//organization !new = [http://purl.obolibrary.org/obo/OBI_0000245, http://purl.obolibrary.org/obo/GO_0016043, http://purl.obolibrary.org/obo/GO_0061024, http://purl.obolibrary.org/obo/GO_0006997, http://purl.obolibrary.org/obo/GO_0044782, http://purl.obolibrary.org/obo/GO_0071840, http://purl.obolibrary.org/obo/ZP_0009085, http://purl.obolibrary.org/obo/ZP_0006720, http://purl.obolibrary.org/obo/ZP_0000307, http://purl.obolibrary.org/obo/ZP_0002292, http://purl.obolibrary.org/obo/ZP_0007526, http://purl.obolibrary.org/obo/ZP_0004360, http://purl.obolibrary.org/obo/HP_0012258, http://purl.obolibrary.org/obo/ZP_0009085, http://purl.obolibrary.org/obo/ZP_0006720, http://purl.obolibrary.org/obo/ZP_0000307, http://purl.obolibrary.org/obo/ZP_0002292, http://purl.obolibrary.org/obo/ZP_0007526, http://purl.obolibrary.org/obo/ZP_0004360, http://purl.obolibrary.org/obo/HP_0012258, http://purl.obolibrary.org/obo/ZP_0009085, http://purl.obolibrary.org/obo/ZP_0006720, http://purl.obolibrary.org/obo/ZP_0000307, http://purl.obolibrary.org/obo/ZP_0002292, http://purl.obolibrary.org/obo/ZP_0007526, http://purl.obolibrary.org/obo/ZP_0004360, http://purl.obolibrary.org/obo/HP_0012258]

		//person !old = [http://d-nb.info/standards/elementset/gnd#Person, http://d-nb.info/standards/elementset/gnd#RealNameOfThePerson, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2272, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5813, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5423, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5336, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_4852, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_377, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_3753, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2272, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5813, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5423, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5336, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_4852, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_377, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_3753]
		//person ! new = [http://d-nb.info/standards/elementset/gnd#PreferredNameOfThePerson, http://d-nb.info/standards/elementset/gnd#FullerFormOfNameOfThePerson, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_11069, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_18094, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_8759, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_17950, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_11069, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_18094, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_8759, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_17950]

		//time !old = [http://purl.obolibrary.org/obo/CMO_0001802, http://purl.obolibrary.org/obo/CMO_0001805, http://purl.obolibrary.org/obo/CMO_0001138, http://purl.obolibrary.org/obo/CMO_0001137, http://purl.obolibrary.org/obo/CMO_0001136, http://purl.obolibrary.org/obo/CMO_0001139, http://purl.obolibrary.org/obo/CMO_0001047, http://purl.obolibrary.org/obo/CMO_0001048, http://purl.obolibrary.org/obo/CMO_0002074, http://purl.obolibrary.org/obo/CMO_0002073, http://purl.obolibrary.org/obo/CMO_0001802, http://purl.obolibrary.org/obo/CMO_0001805, http://purl.obolibrary.org/obo/CMO_0001138, http://purl.obolibrary.org/obo/CMO_0001137, http://purl.obolibrary.org/obo/CMO_0001136, http://purl.obolibrary.org/obo/CMO_0001139, http://purl.obolibrary.org/obo/CMO_0001047, http://purl.obolibrary.org/obo/CMO_0001048, http://purl.obolibrary.org/obo/CMO_0002074, http://purl.obolibrary.org/obo/CMO_0002073, http://purl.obolibrary.org/obo/CMO_0001802, http://purl.obolibrary.org/obo/CMO_0001805, http://purl.obolibrary.org/obo/CMO_0001138, http://purl.obolibrary.org/obo/CMO_0001137, http://purl.obolibrary.org/obo/CMO_0001136, http://purl.obolibrary.org/obo/CMO_0001139, http://purl.obolibrary.org/obo/CMO_0001047, http://purl.obolibrary.org/obo/CMO_0001048, http://purl.obolibrary.org/obo/CMO_0002074, http://purl.obolibrary.org/obo/CMO_0002073, http://www.freeclass.eu/freeclass_v1#C_A563-tax, http://www.freeclass.eu/freeclass_v1#C_A730-tax, http://www.freeclass.eu/freeclass_v1#C_A93-tax, http://www.freeclass.eu/freeclass_v1#C_A776-tax, http://www.freeclass.eu/freeclass_v1#C_A1283-tax, http://www.freeclass.eu/freeclass_v1#C_A736-tax, http://www.freeclass.eu/freeclass_v1#C_A1294-tax, http://www.freeclass.eu/freeclass_v1#C_A1284-gen, http://purl.obolibrary.org/obo/CMO_0001802, http://purl.obolibrary.org/obo/CMO_0001805, http://purl.obolibrary.org/obo/CMO_0001138, http://purl.obolibrary.org/obo/CMO_0001137, http://purl.obolibrary.org/obo/CMO_0001136, http://purl.obolibrary.org/obo/CMO_0001139, http://purl.obolibrary.org/obo/CMO_0001047, http://purl.obolibrary.org/obo/CMO_0001048, http://purl.obolibrary.org/obo/CMO_0002074, http://purl.obolibrary.org/obo/CMO_0002073]
		//time !new = [http://purl.obolibrary.org/obo/CMO_0000932, http://purl.obolibrary.org/obo/CMO_0001450, http://purl.obolibrary.org/obo/CMO_0002017, http://purl.obolibrary.org/obo/CMO_0001264, http://purl.obolibrary.org/obo/CMO_0001115, http://purl.obolibrary.org/obo/CMO_0000942, http://purl.obolibrary.org/obo/CMO_0001962, http://purl.obolibrary.org/obo/CMO_0000932, http://purl.obolibrary.org/obo/CMO_0001450, http://purl.obolibrary.org/obo/CMO_0002017, http://purl.obolibrary.org/obo/CMO_0001264, http://purl.obolibrary.org/obo/CMO_0001115, http://purl.obolibrary.org/obo/CMO_0000942, http://purl.obolibrary.org/obo/CMO_0001962, http://purl.obolibrary.org/obo/CMO_0000932, http://purl.obolibrary.org/obo/CMO_0001450, http://purl.obolibrary.org/obo/CMO_0002017, http://purl.obolibrary.org/obo/CMO_0001264, http://purl.obolibrary.org/obo/CMO_0001115, http://purl.obolibrary.org/obo/CMO_0000942, http://purl.obolibrary.org/obo/CMO_0001962, http://www.freeclass.eu/freeclass_v1#C_A1463-tax, http://www.freeclass.eu/freeclass_v1#C_A1463-gen, http://www.freeclass.eu/freeclass_v1#C_A1539-gen, http://www.freeclass.eu/freeclass_v1#C_A104-tax, http://www.freeclass.eu/freeclass_v1#C_A104-gen, http://www.freeclass.eu/freeclass_v1#C_A841-tax, http://www.freeclass.eu/freeclass_v1#C_A1844-tax, http://www.freeclass.eu/freeclass_v1#C_A1283-gen, http://purl.obolibrary.org/obo/CMO_0000932, http://purl.obolibrary.org/obo/CMO_0001450, http://purl.obolibrary.org/obo/CMO_0002017, http://purl.obolibrary.org/obo/CMO_0001264, http://purl.obolibrary.org/obo/CMO_0001115, http://purl.obolibrary.org/obo/CMO_0000942, http://purl.obolibrary.org/obo/CMO_0001962]

		PersonMap person = PersonMap.getDefaultMap();
		PrimaryTreeMap<String, String> personmap = person.get_person_map();
		
	//	ArrayList<String> newList  = new ArrayList<String>()"[http://d-nb.info/standards/elementset/gnd#Person, http://d-nb.info/standards/elementset/gnd#RealNameOfThePerson, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2272, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5813, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5423, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5336, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_4852, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_377, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_3753, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2272, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5813, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5423, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5336, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_4852, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_377, http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_3753]";
			
		
		
		
//		ArrayList<String> oldList = readFile("time");
//		ArrayList<String> newList = readFile("time_new");
//		
//		ArrayList<String> notFound = new ArrayList<String>();
//		
//		for(int i =0; i< newList.size() ; i ++ ){
//			if (oldList.contains(newList.get(i))){
//				
//			} else {
//				notFound.add(newList.get(i));
//			}
//		}
		
//		for(int i =0; i< oldList.size() ; i ++ ){
//			if (newList.contains(oldList.get(i))){
//				
//			} else {
//				notFound.add(oldList.get(i));
//			}
//		}
//
//		System.out.println(notFound);
		
		
		
	}
	
	
	public static ArrayList<String> readFile(String name) {
		
		ArrayList<String> results = new ArrayList<String>();
		
		String csvFile = "/usr/local/data/files/"+name+".csv";
		BufferedReader br = null;
		String line = "";
	//	String cvsSplitBy = " ";
	 
		try {
	 
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				results.add(line);
				System.out.println(line);
			}
	 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	 
		System.out.println("Done");
	  
 return results;
}
}
