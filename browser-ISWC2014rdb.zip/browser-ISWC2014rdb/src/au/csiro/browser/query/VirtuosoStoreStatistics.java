package au.csiro.browser.query;

import java.util.ArrayList;
import java.util.UUID;

import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

import au.csiro.browser.store.QuadStore;

public class VirtuosoStoreStatistics {

	QuadStore store= QuadStore.getDefaultStore();
	VirtGraph connection= store.getConnection();
	public static int count = -1;
	
	public int getOntologyCount(){
		int count =0;
		
		String sparql = "SELECT (count(DISTINCT ?graph) as ?count) WHERE {GRAPH ?graph {?subject ?predicate ?object}}";
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);
		
		try {
	    	ResultSet results = vqe.execSelect();
	  		QuerySolution result = results.nextSolution();
	    	  count = Integer.parseInt(result.get("count").toString().split("\\^")[0]);
      	  } catch (Exception exp) {
	      	  System.out.println("Can't process select query because of "+exp);
	      } finally {
	      	  vqe.close();
	      }

		return count;
		
	}
	
	public int getTripleCount(){
		int count =0;
		
		String sparql = "SELECT (count(?graph) as ?count) WHERE {GRAPH ?graph {?subject ?predicate ?object} FILTER (?graph != <http://browser.csiro.au/metadata>)}";
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);
		
		try {
	    	ResultSet results = vqe.execSelect();
	  		QuerySolution result = results.nextSolution();
	    	  count = Integer.parseInt(result.get("count").toString().split("\\^")[0]);
      	  } catch (Exception exp) {
	      	  System.out.println("Can't process select query because of "+exp);
	      } finally {
	      	  vqe.close();
	      }

		return count;
		
	}
	
	public int getClassesCount(){
		int count =0;
		
		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"
				+ "PREFIX owl:<http://www.w3.org/2002/07/owl#>"
				+ "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
				+ "SELECT (count(DISTINCT ?subject) as ?count) "
				+ "WHERE {GRAPH ?graph "
				+ "{{?subject rdf:type rdfs:Class} "
				+ "UNION {?subject rdf:type owl:Class} "
				+ "UNION {?subject rdf:type rdf:Class} "
				+ "} FILTER (?graph != <http://browser.csiro.au/metadata>)}";
		
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);
		
		try {
	    	ResultSet results = vqe.execSelect();
	  		QuerySolution result = results.nextSolution();
	    	  count = Integer.parseInt(result.get("count").toString().split("\\^")[0]);
      	  } catch (Exception exp) {
	      	  System.out.println("Can't process select query because of "+exp);
	      } finally {
	      	  vqe.close();
	      }

		return count;
		
	}
	
	public int getPropertiesCount(){
		int count =0;
		
		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"
				+ "PREFIX owl:<http://www.w3.org/2002/07/owl#>"
				+ "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
				+ "SELECT (count(DISTINCT ?subject) as ?count) "
				+ "WHERE {GRAPH ?graph "
				+ "{{?subject rdf:type rdfs:Property} "
				+ "UNION {?subject rdf:type owl:Property} "
				+ "UNION {?subject rdf:type rdf:Property} "
				+ "} FILTER (?graph != <http://browser.csiro.au/metadata>)}";
		
		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);
		
		try {
	    	ResultSet results = vqe.execSelect();
	  		QuerySolution result = results.nextSolution();
	    	  count = Integer.parseInt(result.get("count").toString().split("\\^")[0]);
      	  } catch (Exception exp) {
	      	  System.out.println("Can't process select query because of "+exp);
	      } finally {
	      	  vqe.close();
	      }

		return count;
		
	}
	
	  public String getKey(){
		    UUID idOne = UUID.randomUUID();

		return idOne.toString();
		  
	  }
	  
	  public ArrayList<String> getQueryStrings(){
		  ArrayList<String> queryMap = new ArrayList<String>();
		  
		  queryMap.add("PERSON"+"|"+ "An individual human being; a man, woman, or child.");
		  queryMap.add("NAME"+"|"+"A proper noun; a word or phrase constituting the individual designation by which a particular person or thing is known, referred to, or addressed.");
		  queryMap.add("EVENT"+"|"+ "The (actual or contemplated) fact of anything happening; the occurrence of.");
		  queryMap.add("TITLE"+"|"+"An inscription placed on or over an object, giving its name or describing it; a legend; sometimes, a placard hung up in a theatre giving the name of the piece, etc");
		  queryMap.add("LOCATION"+"|"+"The fact or condition of occupying a particular place; local position, situation. Also, position in a series or succession.");
		  queryMap.add("ADDRESS"+"|"+"The particulars of the place where a person lives or an organization is situated, typically consisting of a number, street name, the name of a town or district, and often a postal code; these particulars considered as a location where a person or organization can be contacted by post.");
		  queryMap.add("DATE"+"|"+"The time during which something lasts; period, season; duration; term of life or existence.");
		  queryMap.add("MUSIC"+"|"+"The art or science of combining vocal or instrumental sounds to produce beauty of form, harmony, melody, rhythm, expressive content, etc.; musical composition, performance, analysis, etc., as a subject of study; the occupation or profession of musicians.");
		  queryMap.add("CITY"+"|"+"A town or other inhabited place.");
		  queryMap.add("PLACE"+"|"+"An open space in a town, a public square, a marketplace.");
		  
		  
		  return queryMap;
	  }
	  
	  public static int getCount(){
		  count++;
		  return count;
		  
	  } 
	
}
