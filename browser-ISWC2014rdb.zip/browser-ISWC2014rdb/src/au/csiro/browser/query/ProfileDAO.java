/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package au.csiro.browser.query;

import au.csiro.browser.core.LoggerService;
import au.csiro.browser.store.QuadStore;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;

import java.util.ArrayList;
import java.util.HashMap;

import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;

/**
 *
 * @author anila
 */
public class ProfileDAO extends LoggerService {

    /**
	 * Default constructor to initializes logging by its parent.
	 */
	
    QuadStore store = QuadStore.getDefaultStore();
    VirtGraph connection = store.getConnection();
    
	public ProfileDAO() {
		super(ProfileDAO.class.getName());
	}

        public ArrayList<MeasureBean> getProfile(String uri) {
        	ArrayList<MeasureBean> arrayList = new ArrayList<MeasureBean>();
        	Model model= ModelFactory.createDefaultModel();


            try {
                    String sparql = getProfileQuery(uri);
                    System.out.println(sparql);
                    QuadStore store = QuadStore.getDefaultStore();
                    model = store.execConstruct(sparql, false);

                    System.out.println(" Model size is : " + model.size());
                    
                    Property props = model.getProperty("http://au.csiro.browser#property");
                    Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
                    Property range = model.getProperty("http://www.w3.org/2000/01/rdf-schema#range");

                    NodeIterator nIt = model.listObjectsOfProperty(props);
                    
                  	while(nIt.hasNext()){
                    	MeasureBean mb = new MeasureBean();
                        String propertyIRI = "";
                        String propertyLabel="";
                        String rangeIRI="";
                        String rangeLabel="";
                  		
                 	 	RDFNode rs = nIt.nextNode();
                 	 	propertyIRI = rs.toString();
                  		
                 	 	Resource property = model.getResource(propertyIRI);

                  		//getLabel of property
                  		NodeIterator nIt2 = model.listObjectsOfProperty(property,label);
                  		if(nIt2.hasNext()){
                  			propertyLabel = nIt2.nextNode().toString();}
                  		
                  		//getObject Value i.e. range
                     	NodeIterator rangeIt = model.listObjectsOfProperty(property,range);
    					
                     	if(rangeIt.hasNext()){
                     		rangeIRI = rangeIt.nextNode().toString();}
    					
    					Resource rangeuri = model.getResource(rangeIRI);
    					NodeIterator rangeLabelIterator = model.listObjectsOfProperty(rangeuri,label);
    					
                     	if(rangeLabelIterator.hasNext()){
                     		rangeLabel = rangeLabelIterator.nextNode().toString();}
                     	
    					System.out.println(propertyIRI + "	" + propertyLabel +"	" + rangeIRI +"		"+ rangeLabel );
    					
    					mb.setProperty(propertyIRI);
    					mb.setPropertyLabel(propertyLabel);
    					mb.setValue(rangeIRI);
    					mb.setValueLabel(rangeLabel);
                        arrayList.add(mb);
                  	}
  

		}catch(Exception e){
			logger.info("Cant Return Dimensions : "+e);
			//return "" + e;
		}
            System.out.println(arrayList);
              return arrayList;
        }

        public ArrayList<String> getProfileOfClass(String uri) {
        	ArrayList<String> arrayList = new ArrayList<String>();
        	Model model= ModelFactory.createDefaultModel();


            try {
                    String sparql = getProfileQuery(uri);
                    System.out.println(sparql);
                    QuadStore store = QuadStore.getDefaultStore();
                    model = store.execConstruct(sparql, false);

                    System.out.println(" Model size is : " + model.size());
                    
                    Property props = model.getProperty("http://au.csiro.browser#property");
                    Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
                    Property range = model.getProperty("http://www.w3.org/2000/01/rdf-schema#range");

                    NodeIterator nIt = model.listObjectsOfProperty(props);
                    
                  	while(nIt.hasNext()){
                    	
                        String propertyIRI = "";
                        String propertyLabel="";
                        String rangeIRI="";
                        String rangeLabel="";
                  		
                 	 	RDFNode rs = nIt.nextNode();
                 	 	propertyIRI = rs.toString();
                  		
                 	 	Resource property = model.getResource(propertyIRI);

                  		//getLabel of property
                  		NodeIterator nIt2 = model.listObjectsOfProperty(property,label);
                  		if(nIt2.hasNext()){
                  			propertyLabel = nIt2.nextNode().toString();}
                  		if (propertyLabel.contains("^")){
                        	propertyLabel  = propertyLabel.split("\\^")[0];
                        } if (propertyLabel.contains("@")){
                        	propertyLabel = propertyLabel.split("@")[0];
                        } if (propertyLabel.equalsIgnoreCase("")){
                        	propertyLabel = propertyIRI;
                        } 
                  		//getObject Value i.e. range
                     	NodeIterator rangeIt = model.listObjectsOfProperty(property,range);
    					
                     	if(rangeIt.hasNext()){
                     		rangeIRI = rangeIt.nextNode().toString();}
    					
    					Resource rangeuri = model.getResource(rangeIRI);
    					NodeIterator rangeLabelIterator = model.listObjectsOfProperty(rangeuri,label);
    					
                     	if(rangeLabelIterator.hasNext()){
                     		rangeLabel = rangeLabelIterator.nextNode().toString();}
                     	
    					System.out.println(propertyIRI + "	" + propertyLabel +"	" + rangeIRI +"		"+ rangeLabel );

                        arrayList.add(propertyIRI + "|" + propertyLabel);
                  	}
  

		}catch(Exception e){
			logger.info("Cant Return Dimensions : "+e);
			//return "" + e;
		}
            System.out.println(arrayList);
              return arrayList;
        }

        
        public HashMap<String,String> getLabelComment(String uri){
        	HashMap<String,String> descrption = new HashMap<String,String>();
        	String sparql ="PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
    	            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
    	            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
    	            "CONSTRUCT { <"+uri+"> rdfs:label ?label."
    	            		+ " <"+uri+"> rdfs:comment ?comment.}"
    	            		+ "WHERE {GRAPH ?g {<"+uri+"> rdfs:label ?label."
    	            		+ "OPTIONAL { {<"+uri+"> rdfs:comment ?comment.} UNION {<"+uri+"> rdfs:description ?comment.}}}}" ;
        
        	System.out.println(sparql);
        	try{
        	 QuadStore store = QuadStore.getDefaultStore();
             Model model = store.execConstruct(sparql, false);
             
             Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
             Property comment = model.getProperty("http://www.w3.org/2000/01/rdf-schema#comment");

             NodeIterator nIt = model.listObjectsOfProperty(label);
             
             String classLabel = "";
           	while(nIt.hasNext()){
                 classLabel = nIt.nextNode().toString();
            }
           	
            NodeIterator nIt2 = model.listObjectsOfProperty(comment);
           
            String classComments = "";
            while(nIt2.hasNext()){
                classComments = nIt2.nextNode().toString();
            }
            
            descrption.put("label", classLabel);
            descrption.put("comment", classComments);
            
            
           	}catch(Exception e){
           		System.out.println(e);
           	}

        	return descrption;
        }

  

        public String getProfileQuery(String uri){

        String sparql ="PREFIX csiro:<http://au.csiro.browser#>" +
            "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
          
            "CONSTRUCT {<"+uri+"> csiro:property ?property. " +
            "?property rdfs:label ?propLabel." +
            "?property rdfs:range ?range. " +
            "?range rdfs:label ?rangeLabel.} "+
 //          "WHERE {{{<http://xmlns.com/foaf/0.1/Agent> rdfs:subClassOf ?res. ?res owl:onProperty ?property.} UNION {{<http://xmlns.com/foaf/0.1/Agent> rdfs:subClassOf ?class. ?property rdfs:domain ?class.} UNION {?property rdfs:domain <http://xmlns.com/foaf/0.1/Agent>}} } {{?res ?resProp ?range.FILTER ((?resProp = owl:allValuesFrom) || (?resProp = owl:someValuesFrom) )} UNION {?property rdfs:range ?range.}} OPTIONAL {?property rdfs:label ?propLabel.} Optional {?range rdfs:label ?rangeLabel.}}";
             "WHERE {GRAPH ?g {"
            	+ "{"
            		+ "{<"+uri+"> rdfs:subClassOf+ ?res. "
            		+ "?res owl:onProperty ?property.} "
            		+ "UNION "
            		+ "{"
            			+ "{<"+uri+"> rdfs:subClassOf+ ?class. "
            			+ "?property rdfs:domain ?class.} "
            			+ "UNION "
            			+ "{?property rdfs:domain <"+uri+">}"
            		+ "} "
            	+ "}"
            	+ "{"
            		+ "{?res ?resProp ?range."
            		+ "FILTER ((?resProp = owl:allValuesFrom) || (?resProp = owl:someValuesFrom) )} "
            		+ "UNION "
            		+ "{?property rdfs:range ?range.}"
            	+ "}"
            	+ "OPTIONAL {?property rdfs:label ?propLabel.}"
            	+ "Optional {?range rdfs:label ?rangeLabel.}"
            	+ "}}";

          logger.info("Prepared SPARQL query successfully");
          logger.info(sparql);
          return sparql;
        }

  

          	public ArrayList<String> getSuperClassList(String concept){
          		//int length = 0 ;
          		
          		ArrayList<String> superClassList = new ArrayList<String>();
          		
          		System.out.println("**************** SuperClass for concept " + concept + " **************** ");
          		
          		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"
          				+ "SELECT DISTINCT ?object ?label "
          				+ "WHERE {GRAPH ?g "
          				+ "{<"+concept+"> rdfs:subClassOf+ ?object."
          				+ " ?object rdf:type ?type."
          				+ "OPTIONAL {?object rdfs:label ?label} "
          				+ "FILTER ( (?type=owl:Class) || (?type = rdfs:Class) )"
          				+ "FILTER(langMatches(lang(?label), \"EN\"))"
          				+ "FILTER (!isBlank(?object))}}";
        		
          		System.out.println(sparql);
          		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);
       		
        		try {
        			
        			ResultSet results = vqe.execSelect();
        			int count =0;

        			while (results.hasNext()) {
        				QuerySolution result = results.nextSolution();
        				String uri = result.get("object").toString();
        				String label = result.getLiteral("label").getLexicalForm();
        				if (label.equalsIgnoreCase("")){
        					label = uri;
        				}
        				superClassList.add(label);
        			}

        		} catch(Exception e){
        			System.out.println(e);
        		} 	finally {
        		
        		}	
        		
          		return superClassList;
          	}
          	
          	public ArrayList<String> getSubClassList(String concept){
          		//int length = 0 ;
          		
          		ArrayList<String> subClassList = new ArrayList<String>();
          		
          		System.out.println("**************** Sub for concept " + concept + " **************** ");
          		
          		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"
          				+ "SELECT DISTINCT ?object ?label "
          				+ "WHERE {GRAPH ?g "
          				+ "{?object rdfs:subClassOf+ <"+concept+">."
          				+ " ?object rdf:type ?type."
          				+ "OPTIONAL {?object rdfs:label ?label} "
          				+ "FILTER ( (?type=owl:Class) || (?type = rdfs:Class) )"
          				+ "FILTER(langMatches(lang(?label), \"EN\"))"
          				+ "FILTER (!isBlank(?object))}}";
        		
          		System.out.println(sparql);
          		VirtuosoQueryExecution vqe = VirtuosoQueryExecutionFactory.create (sparql, connection);
       		
        		try {
        			
        			ResultSet results = vqe.execSelect();
        			int count =0;

        			while (results.hasNext()) {
        				QuerySolution result = results.nextSolution();
        				String uri = result.get("object").toString();
        				String label = result.getLiteral("label").getLexicalForm();
        				if (label.equalsIgnoreCase("")){
        					label = uri;
        				}
        				subClassList.add(label);
        			}
        		} catch(Exception e){
        			System.out.println(e);
        		} 		
          		return subClassList;
          	}



}
