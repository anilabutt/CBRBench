/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package au.csiro.browser.query;

import au.csiro.browser.core.LoggerService;
import au.csiro.browser.store.QuadStore;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author anila
 */
public class MeasureDAO extends LoggerService {

    /**
	 * Default constructor to initializes logging by its parent.
	 */
	public MeasureDAO() {
		super(MeasureDAO.class.getName());
	}

        public Model getSearchResults(ArrayList<String> searchStringArray) {
        	Model result = ModelFactory.createDefaultModel();
        	System.out.println(searchStringArray);
                List<SearchBean> arrayList = new ArrayList<SearchBean>();
                try {
                	String sparql = getSearchQuery(searchStringArray);
                    QuadStore store = QuadStore.getDefaultStore();
                    result = store.execConstruct(sparql, true);
                } catch(Exception exp) {
                	logger.info("Exception in getSearchResults "+exp);
                }
                return result;
        }

//        public Model getFilteredSearchResults(List<String> searchString, String range) {
//        	List<SearchBean> arrayList = new ArrayList<SearchBean>();
//        	String sparql="";
//        	sparql= getFilteredResultsQuery(searchString, range);
//        	
//            QuadStore store = QuadStore.getDefaultStore();
//			Model result = store.execConstruct(sparql, false);            	
//                return result;
//        }

//         public List<SearchBean> getUpdatedSearchResults(String range) {
//                List<SearchBean> arrayList = new ArrayList<SearchBean>();
//		String sparql = getUpdatedResultsQuery(range);
//                QuadStore store = QuadStore.getDefaultStore();
//			Model result = store.execConstruct(sparql, false);
//                        StmtIterator iter = result.listStatements();
//                        while (iter.hasNext()){
//                            Statement stmt = iter.nextStatement();
//                            SearchBean mb = new SearchBean();
//                            mb.setId(stmt.getSubject().toString());
//                            mb.setLabel(stmt.getLiteral().getLexicalForm());
//                            arrayList.add(mb);
//                        }
//
//                return arrayList;
//	}
        

//        public List<SearchBean> getAllRelevantMeasures(String Id) {
//            List<SearchBean> arrayList = new ArrayList<SearchBean>();
//            try {
//		String sparql = getRelevantMeasuresQuery(Id);
//		QuadStore store = QuadStore.getDefaultStore();
//			Model result = store.execConstruct(sparql, false);
//                        StmtIterator iter = result.listStatements();
//                        while (iter.hasNext()){
//                            Statement stmt = iter.nextStatement();
//                            SearchBean mb = new SearchBean();
//                            mb.setId(stmt.getSubject().toString());
//                            mb.setLabel(stmt.getLiteral().getLexicalForm());
//                            arrayList.add(mb);
//                        }
//		}catch(Exception e){
//			logger.info("Cant Return Dimensions : "+e);
//			//return "" + e;
//		}
//              return arrayList;
//	}

        public ArrayList<MeasureBean> getProfile(String uri) {
        	ArrayList<MeasureBean> arrayList = new ArrayList<MeasureBean>();
        	Model model= ModelFactory.createDefaultModel();
            String crange = "";
            String crangeLabel = "";
            int count=0;

            try {
                    String sparql = getProfileQuery(uri);
                    System.out.println(sparql);
                    QuadStore store = QuadStore.getDefaultStore();
                    model = store.execConstruct(sparql, false);

                    System.out.println(" Model size is : " + model.size());
                    
                    Property props = model.getProperty("http://au.csiro.browser#property");
                    Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
                    Property range = model.getProperty("http://www.w3.org/2000/01/rdf-schema#range");

                    NodeIterator nIt = model.listObjectsOfProperty(props);
                    
                  	while(nIt.hasNext()){
                    	MeasureBean mb = new MeasureBean();
                        String propertyIRI = "";
                        String propertyLabel="";
                        String rangeIRI="";
                        String rangeLabel="";
                  		
                 	 	RDFNode rs = nIt.nextNode();
                 	 	propertyIRI = rs.toString();
                  		
                 	 	Resource property = model.getResource(propertyIRI);

                  		//getLabel of property
                  		NodeIterator nIt2 = model.listObjectsOfProperty(property,label);
                  		if(nIt2.hasNext()){
                  			propertyLabel = nIt2.nextNode().toString();}
                  		
                  		//getObject Value i.e. range
                     	NodeIterator rangeIt = model.listObjectsOfProperty(property,range);
    					
                     	if(rangeIt.hasNext()){
                     		rangeIRI = rangeIt.nextNode().toString();}
    					
    					Resource rangeuri = model.getResource(rangeIRI);
    					NodeIterator rangeLabelIterator = model.listObjectsOfProperty(rangeuri,label);
    					
                     	if(rangeLabelIterator.hasNext()){
                     		rangeLabel = rangeLabelIterator.nextNode().toString();}
                     	
    					System.out.println(propertyIRI + "	" + propertyLabel +"	" + rangeIRI +"		"+ rangeLabel );
    					
    					mb.setProperty(propertyIRI);
    					mb.setPropertyLabel(propertyLabel);
    					mb.setValue(rangeIRI);
    					mb.setValueLabel(rangeLabel);
                        arrayList.add(mb);
                  	}
  

		}catch(Exception e){
			logger.info("Cant Return Dimensions : "+e);
			//return "" + e;
		}
            System.out.println(arrayList);
              return arrayList;
        }

        public Model getCompleteSearchResults(ArrayList<String> q) {
            
                    String sparql = getSearchQuery1(q);
                    QuadStore store = QuadStore.getDefaultStore();
                    Model result = store.execConstruct(sparql, false);
                   
                        /**************/
                    return result;
        }

          public Model getListFacets(String id) {

                    String sparql = getFacetQuery(id);
                    QuadStore store = QuadStore.getDefaultStore();
                    Model result = store.execConstruct(sparql, false);

                    return result;
        }

        public String getSearchQuery(ArrayList<String> q){

        	String firstWord = "";
        	if(q.isEmpty())
        	System.out.println("querywords number is  : "+q.size());
        	else firstWord = q.get(0);
        	
            String first = "PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>" +
                " PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
                " PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
                " PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
                " CONSTRUCT {?uri rdfs:graph ?g.?uri rdfs:label ?value}" +
                " Where {GRAPH ?g {" +
                " ?uri rdfs:label ?value." +
                " { {?uri rdf:type rdfs:Class.} UNION { ?uri rdf:type owl:Class.} }" +
    	        " FILTER (regex(?value, \""+ firstWord +"\", \"i\")";
	       
            
            String middle  = ""; 
  	      	for(int i=1; i<q.size(); i++ ){
  	    	  middle = middle + " || regex(?value, \""+ q.get(i) +"\", \"i\")";
  	      	}
  	      	
  	      	String last =  " )}}" ;
  	      	
  	      	String sparql = first+middle+last;
            logger.info("GET query prepared");
            logger.info(sparql);
            return sparql;
        }
        
        public HashMap<String,String> getLabelComment(String uri){
        	HashMap<String,String> descrption = new HashMap<String,String>();
        	String sparql ="PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
    	            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
    	            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
    	            "CONSTRUCT { <"+uri+"> rdfs:label ?label."
    	            		+ "<"+uri+"> rdfs:comment ?comment.}"
    	            + "WHERE {GRAPH ?g {<"+uri+"> rdfs:label ?label."
    	            		+ "OPTIONAL {<"+uri+"> rdfs:comment ?comment.}}}" ;
        
        	System.out.println(sparql);
        	try{
        	 QuadStore store = QuadStore.getDefaultStore();
             Model model = store.execConstruct(sparql, false);
             
             Property label = model.getProperty("http://www.w3.org/2000/01/rdf-schema#label");
             Property comment = model.getProperty("http://www.w3.org/2000/01/rdf-schema#comment");

             NodeIterator nIt = model.listObjectsOfProperty(label);
             
             String classLabel = "";
           	while(nIt.hasNext()){
                 classLabel = nIt.nextNode().toString();
            }
           	
            NodeIterator nIt2 = model.listObjectsOfProperty(comment);
           
            String classComments = "";
            while(nIt2.hasNext()){
                classComments = nIt2.nextNode().toString();
            }
            
            descrption.put("label", classLabel);
            descrption.put("comment", classComments);
            
            
           	}catch(Exception e){
           		System.out.println(e);
           	}

        	return descrption;
        }

        public String getSearchQuery1(ArrayList<String> q){

//        	 String sparql ="PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>" +
//        	            "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
//        	            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
//        	            "PREFIX pf: <http://jena.hpl.hp.com/ARQ/property#>"+
//        	            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
//        	            "CONSTRUCT { ?uri rdfs:label ?label." +
//        	            "?uri ortho:hasProperty ?property. " +
//        	            "?property rdfs:label ?propLabel." +
//        	            "?property rdfs:range ?range. " +
//        	            "?range rdfs:label ?rangeLabel.}" +
//        	            "WHERE {GRAPH ?g {" +
//        	            "?uri rdfs:label ?value." +
//        	            "?uri rdfs:subClassOf ?restriction." +
//        	            "?restriction owl:onProperty ?property. " +
//        	            " { {?restriction owl:allValuesFrom ?range. ?range rdfs:label ?rangeLabel} " +
//        	            "	UNION " +
//        	            "	{?restriction owl:someValuesFrom ?range. ?range rdfs:label ?rangeLabel} " +
//        	            "	UNION " +
//        	            "	{?restriction owl:hasValue ?range. ?range rdfs:label ?rangeLabel} " +
//        	            " } "+
//        	            "?property rdfs:label ?propLabel." +
//        		        "FILTER regex(?value, \""+ q +"\", \"i\")"+
//        	            "}}" ;
        	String firstWord = "";
        	if(q.isEmpty())
        	System.out.println("querywords number is  : "+q.size());
        	else firstWord = q.get(0);
        	
        	String first ="PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>" +
            "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
            "PREFIX pf: <http://jena.hpl.hp.com/ARQ/property#>"+
            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
            "CONSTRUCT { ?uri rdfs:graph ?g."
            + "?uri rdfs:label ?label." +
            "?uri ortho:hasProperty ?property. " +
            "?property rdfs:label ?propLabel." +
            "?property rdfs:range ?range. " +
            "?range rdfs:label ?rangeLabel.}" +
            "WHERE {GRAPH ?g {" +
            "?uri rdfs:label ?value." +
            "{{ {{?uri rdfs:subClassOf ?restriction.} UNION {?uri rdfs:subClassOf ?superClass. ?superClass rdfs:subClassOf ?restriction.} }" +
            "?restriction owl:onProperty ?property. " +
            "{?restriction ?restProp ?range. Filter ( (?restProp = owl:allValuesFrom) || (?restProp = owl:someValuesFrom) || (?restProp = owl:hasValue) )}"
            + "} UNION { "
            + "{ {?property rdfs:domain ?uri.}"
        	+ " UNION " +
        		"{?property rdfs:domain ?superClass." +
        		"?uri rdfs:subClassOf ?superClass." +
        		"FILTER (?superClass != owl:Thing) } " +
        		"}" 
            + " ?property rdfs:range ?range.} }"+
            "Optional {?property rdfs:label ?propLabel.}" +
            "Optional {?range rdfs:label ?rangeLabel.}"+

	        "FILTER (regex(?value, \""+ firstWord +"\", \"i\")" ;
        	
            String middle  = ""; 
  	      	for(int i=1; i<q.size(); i++ ){
  	    	  middle = middle + " || regex(?value, \""+ q.get(i) +"\", \"i\")";
  	      	}
  	      	
  	      	String last =  " )}}" ;
  	      	
  	      	
  	      	String sparql = first+middle+last;
            logger.info("GET query prepared");
            logger.info(sparql);
            return sparql;
        }

        public String getProfileQuery(String uri){

        String sparql ="PREFIX csiro:<http://au.csiro.browser#>" +
            "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
          
            "CONSTRUCT {<"+uri+"> csiro:property ?property. " +
            "?property rdfs:label ?propLabel." +
            "?property rdfs:range ?range. " +
            "?range rdfs:label ?rangeLabel.} "+
 //          "WHERE {{{<http://xmlns.com/foaf/0.1/Agent> rdfs:subClassOf ?res. ?res owl:onProperty ?property.} UNION {{<http://xmlns.com/foaf/0.1/Agent> rdfs:subClassOf ?class. ?property rdfs:domain ?class.} UNION {?property rdfs:domain <http://xmlns.com/foaf/0.1/Agent>}} } {{?res ?resProp ?range.FILTER ((?resProp = owl:allValuesFrom) || (?resProp = owl:someValuesFrom) )} UNION {?property rdfs:range ?range.}} OPTIONAL {?property rdfs:label ?propLabel.} Optional {?range rdfs:label ?rangeLabel.}}";
             "WHERE {GRAPH ?g {"
            	+ "{"
            		+ "{<"+uri+"> rdfs:subClassOf+ ?res. "
            		+ "?res owl:onProperty ?property.} "
            		+ "UNION "
            		+ "{"
            			+ "{<"+uri+"> rdfs:subClassOf+ ?class. "
            			+ "?property rdfs:domain ?class.} "
            			+ "UNION "
            			+ "{?property rdfs:domain <"+uri+">}"
            		+ "} "
            	+ "}"
            	+ "{"
            		+ "{?res ?resProp ?range."
            		+ "FILTER ((?resProp = owl:allValuesFrom) || (?resProp = owl:someValuesFrom) )} "
            		+ "UNION "
            		+ "{?property rdfs:range ?range.}"
            	+ "}"
            	+ "OPTIONAL {?property rdfs:label ?propLabel.}"
            	+ "Optional {?range rdfs:label ?rangeLabel.}"
            	+ "}}";

          logger.info("Prepared SPARQL query successfully");
          logger.info(sparql);
          return sparql;
        }

        public String getRelevantMeasuresQuery(String Id){

       String sparql ="PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>" +
			"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
			"PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
			"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
			"PREFIX pf: <http://jena.hpl.hp.com/ARQ/property#>"+

	        "Construct {?measure rdfs:label ?label} WHERE {" +
	        "?measure rdfs:subClassOf ?restriction. " +
	        "?restriction owl:onProperty ?property. " +
	        " { {?restriction owl:allValuesFrom <"+Id+">} " +
	        "	UNION " +
	        "	{?restriction owl:someValuesFrom <"+Id+">} " +
                "	UNION " +
	        "	{?restriction owl:hasValue <"+Id+">} " +
	        " } "+
	        "?measure rdfs:label ?label." +
	        "} " ;

          logger.info("Prepared SPARQL query successfully");
          logger.info(sparql);
          return sparql;
        }

         public String getFilteredResultsQuery(List q, String str){

	      String dimensions[] = str.split("\\|");
	      String Id = dimensions[1];
	      
	    String firstWord = "";
      	if(q.isEmpty())
      	System.out.println("querywords number is  : "+q.size());
      	else firstWord = q.get(0).toString();
      	
	        String first1 ="PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>"+
	                "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
	                "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-synmelanomatax-ns#>" +
	                "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+

	             "Construct {?measure rdfs:graph ?g. "
	             + "?measure rdfs:label ?value} "
	             + "WHERE { "
	             + "GRAPH ?g {" 
	             +"?measure rdfs:label ?value." 
	    	     +"FILTER ( (regex(?value, \""+ firstWord +"\", \"i\"))";
            String middle1  = ""; 
  	      	for(int i=1; i<q.size(); i++ ){
  	    	  middle1 = middle1 + " || (regex(?value, \""+ q.get(i) +"\", \"i\")) ";
  	      	}
  	      	
  	      	String last1 =  " )" ;
	    	String first2 = "{"
             		+ "{"
         			+ "{?measure rdfs:subClassOf ?restriction."
         			+ " ?restriction owl:onProperty ?property.}"
         			+ " UNION "
         			+ "{?measure rdfs:subClassOf ?superClass."
         			+ "?superClass rdfs:subClassOf ?restriction."
         			+ "?restriction owl:onProperty ?property.}"
         		+ "} "
         		+ "UNION "
         		+ "{"
         			+ "{ "
         				+ "{?property rdfs:domain ?measure.} "
         				+ "UNION "
         				+ "{?property rdfs:domain ?superClass."
         				+ "?measure rdfs:subClassOf ?superClass."
         				+ "FILTER (?superClass != owl:Thing) } "
         			+ "}"
         		+ "}"
         	+ "}"
         + " Filter ( (?property = <"+Id+">) ";

	      String middle2  = ""; 
	      for(int i=2; i<dimensions.length; i++ ){
	    	  middle2 = middle2 + " || (?property = <"+ dimensions[i]+">)";
	      }
	      String last2 = ")} }" ;

           String sparql = first1+middle1+last1 +first2+middle2+last2;
            logger.info("Prepared SPARQL query successfully");
            logger.info(sparql);
            return sparql;
        }

          public String getFacetQuery(String id){

             String sparql ="PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>" +
            "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
            "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
                     "PREFIX pf: <http://jena.hpl.hp.com/ARQ/property#>"+
            "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
            "CONSTRUCT { ?uri rdfs:label ?label." +
            "?uri ortho:hasProperty ?property. " +
            "?property rdfs:label ?propLabel." +
            "?property rdfs:range ?range. " +
            "?range rdfs:label ?rangeLabel.}" +
            "WHERE { GRAPH ?g {" +
            "?uri rdfs:subClassOf ?restriction1." +
            "?restriction1 owl:onProperty ?property1. " +
            " { {?restriction1 owl:allValuesFrom <"+id+">.} UNION {?restriction1 owl:someValuesFrom <"+id+">.} UNION {?restriction1 owl:hasValue <"+id+">.}} "+
            "?uri rdfs:subClassOf ?restriction." +
            "?restriction owl:onProperty ?property. " +
            " { {?restriction owl:allValuesFrom ?range. ?range rdfs:label ?rangeLabel} " +
            "	UNION " +
            "	{?restriction owl:someValuesFrom ?range. ?range rdfs:label ?rangeLabel} " +
            "	UNION " +
            "	{?restriction owl:hasValue ?range. ?range rdfs:label ?rangeLabel} " +
            " } "+
            "?property rdfs:label ?propLabel." +
            "}}" ;
            logger.info("GET query prepared");
            logger.info(sparql);
            return sparql;
        }

           public String getUpdatedResultsQuery(String str){

        	   logger.info("String value for the query is :" + str);
              String middlePart="";
	      String dimensions[] = str.split("\\|");
	      String Id = dimensions[1];

        String sparql ="PREFIX ifkm:<http://purl.org/ontology/ifkm#>" +
        "PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>"+
        "PREFIX nust:<http://ifkm.nust.edu.pk/> " +
        "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
        "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>" +
        "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
        "PREFIX pf: <http://jena.hpl.hp.com/ARQ/property#>"+

     "Construct {?measure rdfs:label ?label} "
     + "WHERE { "
     + "GRAPH ?g {" +
     "{?measure rdfs:subClassOf ?restriction. " +
     "?restriction owl:onProperty ?property.} "
     + " UNION "
     + "{?property rdfs:domain ?measure."
     + "?property rdfs:range ?range. } "
     + " Filter (?property = <"+Id+">)} "
     + "}" ;
	      
//            String firstPart ="PREFIX ifkm:<http://purl.org/ontology/ifkm#>" +
//                   "PREFIX ortho:<http://www.biomeanalytics.com/model/orthoOntology.owl#>"+
//                   "PREFIX nust:<http://ifkm.nust.edu.pk/> " +
//                   "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
//                   "PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>" +
//                   "PREFIX owl:<http://www.w3.org/2002/07/owl#>"+
//                   "PREFIX pf: <http://jena.hpl.hp.com/ARQ/property#>"+
//
//                "Construct {?measure rdfs:label ?label} WHERE {" +
//                "?measure rdfs:subClassOf ?restriction. " +
//	        "?restriction owl:onProperty ?property. " +
//	        " { {?restriction owl:allValuesFrom <"+Id+">} UNION {?restriction owl:someValuesFrom <"+Id+">.} UNION {?restriction owl:hasValue <"+Id+">.}}" ;
//
//                for(int i=2; i<dimensions.length; i++ ){
//                    middlePart = middlePart + " ?measure rdfs:subClassOf ?restriction"+i+". ?restriction"+i+" owl:onProperty ?property"+i+". { {?restriction"+i+" owl:allValuesFrom <"+dimensions[i]+">} UNION {?restriction"+i+" owl:someValuesFrom <"+dimensions[i]+">.} UNION {?restriction"+i+" owl:hasValue <"+dimensions[i]+">.}}";  }
//	        String lastPart = "  ?measure rdfs:label ?label." +
//	        "} " ;
//
//         
//            String sparql = firstPart+middlePart+lastPart;
            logger.info("Prepared SPARQL query successfully");
            logger.info(sparql);
            return sparql;
        }

          	public ArrayList<String> getSuperClassList(String concept, String graphIRI){
          		//int length = 0 ;
          		
          		ArrayList<String> superClassList = new ArrayList<String>();
          		
          		System.out.println("**************** SuperClass for concept " + concept + " **************** ");
          		
          		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
          						"CONSTRUCT {<"+concept+"> rdfs:subClassOf ?object}"
        						+ " FROM <"+graphIRI+"> "
        						+ " WHERE {<"+concept+"> rdfs:subClassOf+ ?object."
        								+ "{?object rdf:type rdfs:Class} UNION {?object rdf:type owl:Class.}"
        								+ "FILTER (!(isBlank(?object)))}";
        		
          		//System.out.println(sparql);
        		
        		try {
        			QuadStore store = QuadStore.getDefaultStore();
        			Model model = store.execConstruct(sparql, false);
        	        Property subClassOf = model.getProperty("http://www.w3.org/2000/01/rdf-schema#subClassOf");
        			NodeIterator nIt = model.listObjectsOfProperty(subClassOf);
        			
        			while (nIt.hasNext()){
        				RDFNode rs = nIt.nextNode();
        	    		System.out.println(rs.toString());
        	    		superClassList.add(rs.toString());
        	    	  }
        		} catch(Exception e){
        			System.out.println(e);
        		} 		
          		return superClassList;
          	}
          	
          	public ArrayList<String> getSubClassList(String concept, String graphIRI){
          		//int length = 0 ;
          		
          		ArrayList<String> subClassList = new ArrayList<String>();
          		
          		System.out.println("**************** SuperClass for concept " + concept + " **************** ");
          		
          		String sparql = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"+
          						"CONSTRUCT {?object rdfs:subClassOf <"+concept+">}"
        						+ " FROM <"+graphIRI+"> "
        						+ " WHERE {?object rdfs:subClassOf+ <"+concept+">."
        							//	+ "?object rdfs:label ?objectLabel."
        								+ "{?object rdf:type rdfs:Class} UNION {?object rdf:type owl:Class.}"
        								+ "FILTER (!(isBlank(?object)))}";
        		
          		//System.out.println(sparql);
        		
        		try {
        			QuadStore store = QuadStore.getDefaultStore();
        			Model model = store.execConstruct(sparql, false);
        	        Property subClassOf = model.getProperty("http://www.w3.org/2000/01/rdf-schema#subClassOf");
        			ResIterator nIt = model.listSubjectsWithProperty(subClassOf);
        			
        			while (nIt.hasNext()){
        				Resource rs = nIt.nextResource();
        	    		System.out.println(rs.toString());
        	    		subClassList.add(rs.toString());
        	    	  }
        		} catch(Exception e){
        			System.out.println(e);
        		} 		
          		return subClassList;
          	}



}
