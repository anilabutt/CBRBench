/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package au.csiro.browser.query;

/**
 *
 * @author anila
 */
public class SearchBean {

    String measureId;
    String measureLabel;

    /******************** Constructor *************************/
    public SearchBean(){
        measureId = "";
        measureLabel = "";
    }

    /******************** Setter Function *************************/

    public void setId(String id) {
        measureId = id; }

    public void setLabel(String label) {
        measureLabel = label; }

    /******************** Getter Function *************************/

    public String getId() {
        return this.measureId; }

    public String getLabel() {
        return this.measureLabel; }


}
