package au.csiro.browser;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

import jdbm.PrimaryTreeMap;
import au.csiro.browser.query.MeasureBean;
import au.csiro.browser.query.ProfileDAO;
import au.csiro.browser.rankingmodel.pageRank.AdjacencyMatrix;
import au.csiro.browser.rankingmodel.pageRank.AdjacencyMatrixComputaions;
import au.csiro.browser.rankingmodel.pageRank.DomainAdjacencyMatrix;
import au.csiro.browser.rankingmodel.pageRank.OutLinksMap;
import au.csiro.browser.rankingmodel.pageRank.PageRank;
import au.csiro.browser.rankingmodel.pageRank.PageRankMap;
import au.csiro.browser.rankingmodel.pageRank.PageRankTF_IDFMap;
import au.csiro.browser.rankingmodel.structuralMetrices.DensityCalculator;
import au.csiro.browser.rankingmodel.structuralMetrices.DensityMap;
import au.csiro.browser.rankingmodel.structuralMetrices.Paths;
import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.userstudy.AddressMap;
import au.csiro.browser.userstudy.AuthorMap;
import au.csiro.browser.userstudy.CityMap;
import au.csiro.browser.userstudy.CountryMap;
import au.csiro.browser.userstudy.DateMap;
import au.csiro.browser.userstudy.EventMap;
import au.csiro.browser.userstudy.LocationMap;
import au.csiro.browser.userstudy.MusicMap;
import au.csiro.browser.userstudy.NameMap;
import au.csiro.browser.userstudy.OrganizationMap;
import au.csiro.browser.userstudy.PersonMap;
import au.csiro.browser.userstudy.PlaceMap;
import au.csiro.browser.userstudy.ProfileMap;
import au.csiro.browser.userstudy.TimeMap;
import au.csiro.browser.userstudy.TitleMap;


public class Test {

	private static Logger logger = Logger.getLogger("TestClass");
	public static void main(String[] args)  {

		double highestValue=0.0;
		String highestValueURI = "";
		 TfIdf_Data tfIdfClass = TfIdf_Data.getDefaultMap();
	   	 PrimaryTreeMap<String, HashMap<String, HashMap<Integer,Double>>> corpus_tfIdf_Map = tfIdfClass.get_tfIdf_Value();
	   	 if(corpus_tfIdf_Map.containsKey("http://xmlns.com/foaf/0.1/")) {
	   	 HashMap<String, HashMap<Integer,Double>> cmap = corpus_tfIdf_Map.get("http://xmlns.com/foaf/0.1/");
	   	 
	   	 for(Map.Entry<String, HashMap<Integer,Double>> entry: cmap.entrySet()){
	   //		System.out.println("**************************");
	   		String key= entry.getKey();
	   		HashMap<Integer,Double> value = entry.getValue();
	   		double tValue = value.get(1);
//  	     System.out.println("Class : "+ highestValueURI);
//		   System.out.println("values : "+ highestValue);
		   	 System.out.println("Class : "+ key + "values : "+ tValue);
//	   		double tf_Idf = value.get(1);
//	   		if (tf_Idf>highestValue){
//	   			highestValue = tf_Idf;
//	   			highestValueURI = key;
//	   		}
	   		
	   	 }
	//   	highestValue=cmap.get("http://xmlns.com/foaf/0.1/Person").get(3);
	//	String highestValueURI = "";
	   	 }
	   	 
//	   System.out.println("Class : "+ highestValueURI);
//	   System.out.println("values : "+ highestValue);
//	   	 
//		ProfileDAO ProfileDAO = new ProfileDAO();
//  //      ArrayList<MeasureBean> mbList = ProfileDAO.getProfile(uri);
//        
//       ProfileMap profile = ProfileMap.getDefaultMap();
//       
//       PrimaryTreeMap<String, HashMap<String,ArrayList<String>>> profileMap = profile.get_profile_map();
//       
//		AdjacencyMatrixComputaions ad = new AdjacencyMatrixComputaions();
		
	//	ad.createAdjacencyMatrix();
	//	ad.createOutLinkMap();
		
//		PageRankTF_IDFMap map = new PageRankTF_IDFMap();
//		Model model = ModelFactory.createDefaultModel();
//		ArrayList<String> queryWords = new ArrayList<String>();
//		PageRank pagerank = new PageRank();
//		pagerank.getRankedClasses(model, queryWords);
//		
//		OutLinksMap map = new OutLinksMap();
//		System.out.println(map.get_outlinks_map().get("http://def.seegrid.csiro.au/isotc211/iso19115/2003/metadata"));
//		PageRankMap pagerankmap = PageRankMap.getDefaultMap();
//		System.out.println(pagerankmap.get_tf_Idf_map());
//		map.initializePageRankScoreForOntologyGraphs();
		
//		DomainAdjacencyMatrix matrix = DomainAdjacencyMatrix.getDefaultMap();
//		PrimaryTreeMap<String, ArrayList<String>> map = matrix.get_domain_adjacency_matrix_map();
//		int count=0;
//		String key="";
//		ArrayList<String> arraylist = new ArrayList<String>();
//		
//		System.out.println(map.get("http://www.ifomis.org/bfo/1.1"));
//		System.out.println(ad.getInlinks("http://purl.org/vocab/vann/"));
	//	TimeMap person = TimeMap.getDefaultMap();

	//	for(Map.Entry<String, String> entry: person.get_time_map().entrySet()) {
	//		count++;
	//		key=entry.getKey();
	//		String value= entry.getValue();
	//		System.out.println(key+"			" + value);
	//		
			//if (key.equalsIgnoreCase("http://purl.obolibrary.org/obo/VT_0002636")) { } else {
			//key = "http://purl.obolibrary.org/obo/VT_0002636";
			//	key = "http://purl.obolibrary.org/obo/VT_0010100";
		
// 		ArrayList<String> newList  = new ArrayList<String>();
// 		String list = "http://d-nb.info/standards/elementset/gnd#Person,http://d-nb.info/standards/elementset/gnd#RealNameOfThePerson,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2272,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5813,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5423,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5336,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_4852,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_377,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_3753,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_2272,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5813,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5423,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_5336,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_4852,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_377,http://www.loria.fr/~coulet/ontology/sopharm/version2.0/disease_ontology.owl#DOID_3753";
//		String[] parts = list.split(",");
//		for (int i=0; i<parts.length ; i++) {
//			key = parts[i];
//			 HashMap<String, String> map= new HashMap<String, String>();
//		        map = ProfileDAO.getLabelComment(key); 
//		      
//		        String label = map.get("label").toString();
//		        if(label.contains("^")){
//		      	  label = label.split("\\^")[0];
//		        } if (label.contains("@")){
//		      	  label = label.split("@")[0];
//		        }
//		        ArrayList<String> labelList = new ArrayList<String>();
//		        labelList.add(label);
//		        
//		        String comment = map.get("comment").toString();
//		      
//		        if(comment.contains("^")){
//		      	  comment = comment.split("\\^")[0];
//		        } if (comment.contains("@")){
//		      	  comment = comment.split("@")[0];
//		        }
//		        
//		        ArrayList<String> commentList = new ArrayList<String>();
//		        commentList.add(comment);
//		        
//		        ArrayList<String> superClasses = ProfileDAO.getSuperClassList(key);
//		        ArrayList<String> subClasses = ProfileDAO.getSubClassList(key);  
//		        ArrayList<String> properties = ProfileDAO.getProfileOfClass(key);
//		        
//		        HashMap<String, ArrayList<String>> profileMapForURI = new  HashMap<String, ArrayList<String>>();
//		        profileMapForURI.put("label", labelList);
//		        profileMapForURI.put("comment", commentList);
//		        profileMapForURI.put("subClasses", subClasses);
//		        profileMapForURI.put("superClasses", superClasses);
//		        profileMapForURI.put("properties", properties);
//		        
//		        profileMap.put(key, profileMapForURI);
//		}
//		//}
//		profile.closeConnection();

	}
	


}
