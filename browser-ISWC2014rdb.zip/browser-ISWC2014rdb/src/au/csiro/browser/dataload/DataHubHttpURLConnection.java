package au.csiro.browser.dataload;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;
 
public class DataHubHttpURLConnection {
 
	private final String USER_AGENT = "Mozilla/5.0";
	
	/** Default logger */
	private Logger logger;
 
	public DataHubHttpURLConnection(){
		logger = Logger.getLogger(getClass().getName());
	}
	// HTTP GET request
	public String sendGet(String url) throws Exception {
 
		String responseString = "";
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
 
		// optional default is GET
		con.setRequestMethod("GET");
 
		//add request header
		con.setRequestProperty("User-Agent", USER_AGENT);
 
		int responseCode = con.getResponseCode();
		logger.info("\nSending 'GET' request to URL : " + url);
		logger.info("Response Code : " + responseCode);
	
		if (responseCode == 200) {

			BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
 
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			responseString = response.toString();
		}
		else {
			logger.info(url + " is not alive");
			responseString = url + " is not alive";
		}
		return responseString;
 
	}
 
	public boolean isAlive (String url){
		
		boolean alive = false;
		// optional default is GET
		try {	
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("GET");
			//add request header
			con.setRequestProperty("User-Agent", USER_AGENT);
 
			int responseCode;
			responseCode = con.getResponseCode();
		
			System.out.println("\nSending 'GET' request to URL : " + url);

			if (responseCode == 200) {
				alive = true;
				}
			} catch (ProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return alive;
	}
}