package au.csiro.browser.dataload;

import java.util.ArrayList;
import java.util.logging.Logger;

import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;
import virtuoso.jena.driver.VirtuosoUpdateFactory;
import virtuoso.jena.driver.VirtuosoUpdateRequest;

import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;

import au.csiro.browser.store.QuadStore;

public class ImportsFinder {
	
	 public QuadStore store =QuadStore.getDefaultStore();
	 private Logger logger;
	 
	 public ArrayList<String> getImportOntologies(String graph){
		 
		 ArrayList<String> existingOntologiesList = new ArrayList<String>();
		 existingOntologiesList = getExistingLoadedOntology();
		 
		 ArrayList<String> ontologiesList = new ArrayList<String>();
		 
		 String queryString = "PREFIX owl:<http://www.w3.org/2002/07/owl#> "+
		 "CONSTRUCT {?uri owl:imports ?ontology} FROM <"+graph+"> WHERE {?uri owl:imports ?ontology. FILTER ((?ontology != <"+graph+">) && (?uri != ?ontology))}";
		 
		 System.out.println(queryString);
		 
		 Model result = store.execConstruct(queryString, false);
		 StmtIterator iter = result.listStatements();
         while (iter.hasNext()){
             Statement stmt = iter.nextStatement();
             String ontology = stmt.getObject().toString();
             System.out.println(" Ontology : " + ontology);
             if(existingOntologiesList.contains(ontology)){
            	 
             } else {
            	 ontologiesList.add(ontology);
             }
            // System.out.println(stmt.getSubject().toString() + " " +stmt.getPredicate().toString() + " " +stmt.getObject().toString() );
         }
         
         
        // logger.info(ontologiesList.toString());
         return ontologiesList;
	 }
	 
	 private ArrayList<String> getExistingLoadedOntology(){
		// TripleStore store2 = TripleStore.getDefaultStore();
		 ArrayList<String> list = new ArrayList<String>();
		 
		 String queryString = "PREFIX owl:<http://www.w3.org/2002/07/owl#> "+
				 "CONSTRUCT {?graph owl:subClassOf owl:Class} "
				 + "WHERE {GRAPH ?graph {?subject ?property ?object}}";
				 
				// System.out.println(queryString);
				 
				 Model result = store.execConstruct(queryString, false);
				 StmtIterator iter = result.listStatements();
		         while (iter.hasNext()){
		             Statement stmt = iter.nextStatement();
		             String ontology = stmt.getSubject().toString();
		             //System.out.println(" Ontology : " + ontology);
		             list.add(ontology);
		         }
		         
		         return list;	         
	 }

}
