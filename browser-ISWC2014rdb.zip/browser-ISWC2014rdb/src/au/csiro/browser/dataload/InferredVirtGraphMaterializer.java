package au.csiro.browser.dataload;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import au.csiro.browser.Configuration;
import au.csiro.browser.store.QuadStore;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.ReasonerRegistry;

import virtuoso.jena.driver.VirtGraph;
import virtuoso.jena.driver.VirtModel;
import virtuoso.jena.driver.VirtuosoQueryExecution;
import virtuoso.jena.driver.VirtuosoQueryExecutionFactory;


public class InferredVirtGraphMaterializer {

	public static VirtGraph connection; 
	public static QuadStore store = QuadStore.getDefaultStore();
	
	public static void main(String[] args) {
		String url = "jdbc:virtuoso://" + Configuration.getProperty(Configuration.VIRTUOSO_INSTANCE) + ":" + Configuration.getProperty(Configuration.VIRTUOSO_PORT);
		String password = Configuration.getProperty(Configuration.VIRTUOSO_PASSWORD); 
		String user = Configuration.getProperty(Configuration.VIRTUOSO_USERNAME);
		
		connection = store.getConnection();
		System.out.println("Connection established .... ");
		
		List<String> al = getAllGraphs(); 
		for(int i =0; i <al.size(); i++){
			
			System.out.println("***************" + al.get(i) + "***************");
			
			VirtGraph graph = new VirtGraph(al.get(i), url, user, password );
			Model virtModel = new VirtModel(graph);
			
			Reasoner reasoner = ReasonerRegistry.getRDFSReasoner();
			InfModel infModel = ModelFactory.createInfModel(reasoner, virtModel);
			infModel.commit();
			
			Iterator<Statement> list = infModel.listStatements();
			ArrayList<Triple> triples = new ArrayList<Triple>();
			int count = 0; 
						
			while(list.hasNext()){
				Statement s = list.next();
				Node subject = Node.createURI(s.getSubject().toString());
				Node predicate = Node.createURI(s.getPredicate().toString());
				RDFNode ob = s.getObject();
				Node object;
				if(ob.isLiteral()){
					object = Node.createLiteral(ob.toString());
			    } else {
			    	object = Node.createURI(ob.toString());
			    }
				Triple t = new Triple(subject, predicate, object);
			    triples.add(t);

			}
			graph.clear();
			graph.getBulkUpdateHandler().add(triples);
			System.out.println("I am finished for .. . " + al.get(i));
			System.out.println(" Total Number of triples AFTER inferencing for this graph is "+ triples.size());
		}
	}
	 
	public static ArrayList<String> getAllGraphs(){
		ArrayList<String> al = new ArrayList<String>();
		String sparql = "PREFIX ssn:<http://purl.oclc.org/NET/ssnx/ssn#>"
				+ " PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>"
		 		+ " SELECT DISTINCT ?graph "
		 		+ " WHERE {GRAPH ?graph {?subject ?predicate ?object}}";

		System.out.println("Execute query=\n"+sparql) ;

		VirtuosoQueryExecution qexec = VirtuosoQueryExecutionFactory.create(sparql, connection) ;
		try {
			ResultSet results = qexec.execSelect();
			while (results.hasNext()){
				QuerySolution result = results.nextSolution();
				Resource node = result.getResource("graph");
				System.out.println(node.toString()) ;
				
				al.add(node.toString());
				}
	        } catch (Exception e){
	        	System.out.println("Can not process results :" + e);
	        }finally {
	            qexec.close() ;
	        }
	     return al;   
	 }
}