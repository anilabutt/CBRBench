package au.csiro.browser.dataload;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
 
public class DataHubJSONParser {
     
	private Logger logger;
	
	public DataHubJSONParser(){
		logger = Logger.getLogger(getClass().getName());
	}
	
	public HashMap<String,List<String>> parseDatahubJSONResponse(String responseString) throws Exception {
 
    	 JSONParser parser = new JSONParser();
 
    	 Object obj = parser.parse(responseString);
    	 JSONObject jsonObject = (JSONObject) obj;
 
    	logger.info("------------ HELP ------------");
		String help = (String) jsonObject.get("help");
		logger.info(help);
		
		logger.info("------------SUCCESS------------");
		boolean success = (Boolean) jsonObject.get("success");
		logger.info(success +"");
		
		logger.info("------------RESULT--------------");
		JSONObject result = (JSONObject) jsonObject.get("result");
		JSONArray resultset = (JSONArray) result.get("results");
		
		logger.info(" * * * * * Total Number of URI's in resultset * * * * *");
		
		long numberOfURLs = (Long) result.get("count");
		logger.info(numberOfURLs+"");
		
	
		// loop array
		Iterator<JSONObject> iterator = resultset.iterator();
		
		HashMap<String,List<String>> ontologyURIMap = new HashMap<String, List<String>>();
		
		logger.info(" * * * * * URIs and Identifier * * * * * ");
		while (iterator.hasNext()) {
			
			JSONObject resource = (JSONObject)iterator.next();
		
			String urlString = (String) resource.get("url");
			String revision_id = (String) resource.get("revision_id");
			
			logger.info(urlString +"      "+ revision_id);
			
			if (ontologyURIMap.containsKey(urlString)){
				List<String> urlIdentifierList = ontologyURIMap.get(urlString);
				urlIdentifierList.add(revision_id);
				ontologyURIMap.put(urlString, urlIdentifierList);
			} else {
				ArrayList<String> identifiers = new ArrayList<String>();
				identifiers.add(revision_id);
				ontologyURIMap.put(urlString, identifiers);
			}
		}
		return ontologyURIMap;
	}
}