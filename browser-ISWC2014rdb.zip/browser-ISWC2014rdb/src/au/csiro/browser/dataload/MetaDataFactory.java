package au.csiro.browser.dataload;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import au.csiro.browser.store.QuadStore;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;

public class MetaDataFactory {

	QuadStore store = QuadStore.getDefaultStore();
	
	public String owl = "http://www.w3.org/2002/07/owl#";
	public String rdf = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
	public String dcat = "http://www.w3.org/ns/dcat#";
	public String dct = "http://purl.org/dc/terms/";

	
	Node rdfTypeURI=null, datasetClassURI=null, identifierPropertyURI=null, dateIssued=null, owlImportsURI=null; 
	
	public MetaDataFactory(){
		owlImportsURI = Node.createURI(owl+"imports");
		rdfTypeURI = Node.createURI(rdf + "type");
		datasetClassURI = Node.createURI(dcat+"Dataset");
		identifierPropertyURI = Node.createURI(dct+"identifier");
		dateIssued = Node.createURI(dct+"issued");
	}
	
	public void addMetadata(String uri, List<String> identifier){

		   
		Node datasetURI = Node.createURI(uri);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		//get current date time with Date()
		Date date = new Date();
	//	System.out.println(dateFormat.format(date));
		Node currentdate = Node.createLiteral(dateFormat.format(date));
		
		List<Triple> triple = new ArrayList<Triple>();
		
		Triple datasetRecord = new Triple (datasetURI, rdfTypeURI ,datasetClassURI);
		triple.add(datasetRecord);
		
		for(int count=0; count < identifier.size() ; count++){
			
			Node identifierNode = Node.createLiteral(identifier.get(count));
			Triple identifierRecord = new Triple (datasetURI, identifierPropertyURI , identifierNode);
			
			triple.add(identifierRecord);
		}
	
		Triple dateOfRecord = new Triple (datasetURI, dateIssued , currentdate );
		triple.add(dateOfRecord);
		
		store.insertMetaGraphData(triple);
	}
	
	public void addImportsMetadata(String uri, List<String> importList){
		

		Triple importRecord;
		Node importOntology;
		Node datasetURI = Node.createURI(uri);
		List<Triple> triple = new ArrayList<Triple>();
		
		for (int i=0; i <importList.size() ; i++){
			importOntology = Node.createURI(importList.get(i));
			importRecord =  new Triple (datasetURI, owlImportsURI, importOntology);
			triple.add(importRecord);
		}
		
		store.insertMetaGraphData(triple);
		
	}
}
