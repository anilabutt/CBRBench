package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class DateMap {
	
	private static DateMap defaultMap;
	
	private PrimaryTreeMap<String, String> date_materialized_map;
	
	private RecordManager recMan;

	public static DateMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new DateMap();
		}
		return defaultMap;
	}
	
	private DateMap(){
		
		String filedate = "/www_exp/data/rankings/userstudy/date_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(filedate);
			String recorddate = "date_table";
			date_materialized_map = recMan.treeMap(recorddate);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_date_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			date_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_date_map() {
		return this.date_materialized_map;
		
		//return date_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
