package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class NameMap {
	
	private static NameMap defaultMap;
	
	private PrimaryTreeMap<String, String> name_materialized_map;
	
	private RecordManager recMan;

	public static NameMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new NameMap();
		}
		return defaultMap;
	}
	
	private NameMap(){
		
		String fileName = "/www_exp/data/rankings/userstudy/name_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileName);
			String recordName = "name_table";
			name_materialized_map = recMan.treeMap(recordName);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_name_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			name_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_name_map() {
		return this.name_materialized_map;
		
		//return name_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
