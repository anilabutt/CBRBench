package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class OrganizationMap {
	
	private static OrganizationMap defaultMap;
	
	private PrimaryTreeMap<String, String> organization_materialized_map;
	
	private RecordManager recMan;

	public static OrganizationMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new OrganizationMap();
		}
		return defaultMap;
	}
	
	private OrganizationMap(){
		
		String fileorganization = "/www_exp/data/rankings/userstudy/organization_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileorganization);
			String recordorganization = "organization_table";
			organization_materialized_map = recMan.treeMap(recordorganization);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_organization_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			organization_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_organization_map() {
		return this.organization_materialized_map;
		
		//return organization_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
