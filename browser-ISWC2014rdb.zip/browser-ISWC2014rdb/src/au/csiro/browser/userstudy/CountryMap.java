package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class CountryMap {
	
	private static CountryMap defaultMap;
	
	private PrimaryTreeMap<String, String> country_materialized_map;
	
	private RecordManager recMan;

	public static CountryMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new CountryMap();
		}
		return defaultMap;
	}
	
	private CountryMap(){
		
		String filecountry = "/www_exp/data/rankings/userstudy/country_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(filecountry);
			String recordcountry = "country_table";
			country_materialized_map = recMan.treeMap(recordcountry);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_country_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			country_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_country_map() {
		return this.country_materialized_map;
		
		//return country_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
