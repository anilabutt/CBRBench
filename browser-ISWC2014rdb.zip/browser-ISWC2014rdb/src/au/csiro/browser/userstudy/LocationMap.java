package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class LocationMap {
	
	private static LocationMap defaultMap;
	
	private PrimaryTreeMap<String, String> location_materialized_map;
	
	private RecordManager recMan;

	public static LocationMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new LocationMap();
		}
		return defaultMap;
	}
	
	private LocationMap(){
		
		String filelocation = "/www_exp/data/rankings/userstudy/location_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(filelocation);
			String recordlocation = "location_table";
			location_materialized_map = recMan.treeMap(recordlocation);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_location_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			location_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_location_map() {
		return this.location_materialized_map;
		
		//return location_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
