package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class MusicMap {
	
	private static MusicMap defaultMap;
	
	private PrimaryTreeMap<String, String> music_materialized_map;
	
	private RecordManager recMan;

	public static MusicMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new MusicMap();
		}
		return defaultMap;
	}
	
	private MusicMap(){
		
		String filemusic = "/www_exp/data/rankings/userstudy/music_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(filemusic);
			String recordmusic = "music_table";
			music_materialized_map = recMan.treeMap(recordmusic);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_music_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			music_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_music_map() {
		return this.music_materialized_map;
		
		//return music_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
