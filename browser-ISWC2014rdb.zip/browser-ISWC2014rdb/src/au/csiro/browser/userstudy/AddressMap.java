package au.csiro.browser.userstudy;

import java.io.IOException;

import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class AddressMap {
	
	private static AddressMap defaultMap;
	
	private PrimaryTreeMap<String, String> address_materialized_map;
	
	private RecordManager recMan;

	public static AddressMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new AddressMap();
		}
		return defaultMap;
	}
	
	private AddressMap(){
		
		String fileaddress = "/www_exp/data/rankings/userstudy/address_database";
	//	String fileaddress = "/usr/local/data/rankings/userstudy/address_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileaddress);
			String recordaddress = "address_table";
			address_materialized_map = recMan.treeMap(recordaddress);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_address_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			address_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_address_map() {
		return this.address_materialized_map;
		
		//return address_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
