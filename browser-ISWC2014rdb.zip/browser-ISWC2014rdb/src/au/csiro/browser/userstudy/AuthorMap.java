package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class AuthorMap {
	
	private static AuthorMap defaultMap;
	
	private PrimaryTreeMap<String, String> author_materialized_map;
	
	private RecordManager recMan;

	public static AuthorMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new AuthorMap();
		}
		return defaultMap;
	}
	
	private AuthorMap(){
		String fileauthor ="/www_exp/data/rankings/userstudy/author_database";
		//String fileauthor = "/usr/local/data/rankings/userstudy/author_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileauthor);
			String recordauthor = "author_table";
			author_materialized_map = recMan.treeMap(recordauthor);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_author_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			author_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_author_map() {
		return this.author_materialized_map;
		
		//return author_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
