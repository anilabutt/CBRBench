package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class PlaceMap {
	
	private static PlaceMap defaultMap;
	
	private PrimaryTreeMap<String, String> place_materialized_map;
	
	private RecordManager recMan;

	public static PlaceMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new PlaceMap();
		}
		return defaultMap;
	}
	
	private PlaceMap(){
		
		String fileplace = "/www_exp/data/rankings/userstudy/place_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileplace);
			String recordplace = "place_table";
			place_materialized_map = recMan.treeMap(recordplace);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_place_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			place_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_place_map() {
		return this.place_materialized_map;
		
		//return place_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
