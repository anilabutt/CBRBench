package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class EventMap {
	
	private static EventMap defaultMap;
	
	private PrimaryTreeMap<String, String> event_materialized_map;
	
	private RecordManager recMan;

	public static EventMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new EventMap();
		}
		return defaultMap;
	}
	
	private EventMap(){
		
		String fileevent = "/www_exp/data/rankings/userstudy/event_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileevent);
			String recordevent = "event_table";
			event_materialized_map = recMan.treeMap(recordevent);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_event_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			event_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_event_map() {
		return this.event_materialized_map;
		
		//return event_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
