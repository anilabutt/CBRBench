package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class ProfileMap {
	
	private static ProfileMap defaultMap;
	
	private PrimaryTreeMap<String, HashMap<String,ArrayList<String>>> profile_materialized_map;
	
	private RecordManager recMan;

	public static ProfileMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new ProfileMap();
		}
		return defaultMap;
	}
	
	private ProfileMap(){
		
		String fileprofile = "/www_exp/data/rankings/userstudy/profile_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileprofile);
			String recordprofile = "profile_table";
			profile_materialized_map = recMan.treeMap(recordprofile);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_profile_map(String classIRI , HashMap<String,ArrayList<String>> map ) {
		// TODO Auto-generated method stub
		try {
			
			profile_materialized_map.put(classIRI, map);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, HashMap<String,ArrayList<String>>> get_profile_map() {
		return this.profile_materialized_map;
		
		//return profile_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
