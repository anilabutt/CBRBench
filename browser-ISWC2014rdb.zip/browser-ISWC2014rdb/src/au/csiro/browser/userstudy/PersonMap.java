package au.csiro.browser.userstudy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import au.csiro.browser.rankingmodel.tf_Idf.TfIdf_Data;
import au.csiro.browser.store.QuadStore;
import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;


public class PersonMap {
	
	private static PersonMap defaultMap;
	
	private PrimaryTreeMap<String, String> person_materialized_map;
	
	private RecordManager recMan;

	public static PersonMap getDefaultMap() {
		if(defaultMap==null) {
			defaultMap = new PersonMap();
		}
		return defaultMap;
	}
	
	private PersonMap(){
		
		String fileName = "/www_exp/data/rankings/userstudy/person_database";
		try {
			recMan = RecordManagerFactory.createRecordManager(fileName);
			String recordName = "person_table";
			person_materialized_map = recMan.treeMap(recordName);
			System.out.println("connection established :");
		} catch (IOException e) {
			System.out.println("can not connect because of :" + e);}
	}
	
	public void save_person_map(String classIRI , String label) {
		// TODO Auto-generated method stub
		try {
			
			person_materialized_map.put(classIRI, label);
		    recMan.commit();
		    
		    /** close record manager */
		   // recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public PrimaryTreeMap<String, String> get_person_map() {
		return this.person_materialized_map;
		
		//return person_map;
	}
	
	public void closeConnection(){
		try {
			recMan.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
