/*
 * Copyright (c) 2014, CSIRO and/or its constituents or affiliates. All rights reserved.
 * Use is subject to license terms.
 */
package au.csiro.browser;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

/**
 * Configuration interface for this API.
 * <p>
 * Usage Example: Configuration.getProperty(Configuration.STORE_PATH)
 * <p>
 * See {@link Configuration#getProperty(String)}
 * 
 * @author anila butt
 */
public class Configuration {
	
	/** Property key for full-text index path */
	public static final String FILES_PATH = "files.path";

	/** Property key for triple store path */
	public static final String RANK_PATH = "ranking.path";
	
	/** Property key for ontology path */
	public static final String ONT_PATH = "ontology.path";
	
	/** Property key for ontology path */
	public static final String STORE_CONTEXT = "store.context";
	
	/** Property key for ontology path */
	public static final String STORE_METADATA = "store.metadata";
	
	public static final String DATA_URL = "data.url";
	
	/** Property key for virtuoso instance */
	public static final String VIRTUOSO_INSTANCE = "virtuoso.instance";
	
	/** Property key for virtuoso port */
	public static final String VIRTUOSO_PORT = "virtuoso.port";
	
	/** Property key for virtuoso username */
	public static final String VIRTUOSO_USERNAME = "virtuoso.username";
	
	/** Property key for virtuoso password */
	public static final String VIRTUOSO_PASSWORD = "virtuoso.password";
	
	/** Default instance of this class */
	private static Configuration instance;
	
	/** Default logger */
	private Logger logger;
	
	/** Default properties */
	private Properties properties = new Properties();
	
	/**
	 * External classes should invoke static methods
	 * instead of instantiating this class.
	 * 
	 * @see #getProperty(String)
	 */
	private Configuration() {
		logger = Logger.getLogger(getClass().getName());
		try {
			// Try loading configuration file otherwise fall back to a default path
			properties.load(getClass().getResourceAsStream("config.properties"));
		} catch (IOException iox) {
			//properties.setProperty(STORE_PATH, "/home/anila/browser/store");
			logger.severe("Error in reading store configuration "+ iox);
		}
	}
	
	/**
	 * Returns default configuration object.
	 */
	private static Configuration getDefaults() {
		if(instance==null) {
			instance = new Configuration();
		}
		return instance;
	}
	
	/**
	 * Gets value of the specified configuration property.
	 * 
	 * @param key Configuration key
	 */
	public static String getProperty(String key) {
		Configuration config = Configuration.getDefaults();
		return config.properties.getProperty(key);
	}
}
