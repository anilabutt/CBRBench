package au.csiro.browser;


import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import au.csiro.browser.query.ResultFormatter;

public class TopResults {

	private ArrayList<String> topResultsList;
	private HashMap<String, Integer> URIcount;
	private HashMap<String, ArrayList<String>> URIoccurance;
	
	public TopResults(){
		topResultsList = new ArrayList<String>();
		URIcount = new HashMap<String, Integer>() ;
		URIoccurance = new HashMap<String, ArrayList<String>>() ;
	}

	
	public void addListToTopResults (ArrayList<ResultFormatter> list, String rankingModel){
		
		int numberOfURIs = 10;
		if (list.size()<10) {
			numberOfURIs = list.size();
		}
		
		for(int j=0; j<numberOfURIs; j++){    
			ResultFormatter searchFacet = (ResultFormatter)list.get(j);
		    String term = searchFacet.getTermIRI();
		    int count=1;
		    ArrayList<String> rankModelList = new ArrayList<String>();
		    
		    if (URIcount.containsKey(term)) {
		    	count = URIcount.get(term);
		    	count = count+1;
		    	URIcount.put(term, count);
		    			    	
		    	rankModelList = URIoccurance.get(term);
		    	rankModelList.add(rankingModel);
		    	URIoccurance.put(term, rankModelList);
		    	
		    } else {
		    	URIcount.put(term, count);
		    	rankModelList.add(rankingModel);
		    	URIoccurance.put(term, rankModelList);
		    }
//		    System.out.println("term " + term + " count " + count);
		}
	}
	
	public HashMap<String, Integer> getURIcountMap(){
		HashMap<String, Integer> sortedMap  = this.sortByValues(URIcount);
		return sortedMap;
	}
	
	public HashMap<String, ArrayList<String>> getURIoccuranceMap(){
		return this.URIoccurance;
	}
	
	  private HashMap<String, Integer> sortByValues(HashMap<String, Integer> map) { 
	       List list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });

	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap<String, Integer> sortedHashMap = new LinkedHashMap<String, Integer>();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey().toString(), Integer.parseInt(entry.getValue().toString()));
	       } 
	       return sortedHashMap;
	  }
	  

	
}